# A1 degisiklik ozeti (yalnizca hata duzeltmeleri)

Yedek: `dmla-ORIGINAL-yedek.zip` (yuklediginiz dosyanin birebir kopyasi). Tam fark: `A1.diff`.

| Dosya | Degisiklik |
|---|---|
| js/game.js | Guvenli depolama + dogrulama, checkpoint sistemi, kapi animasyonu/carpismasi, ses durdurma, yeni oyun onayi, restart |
| js/i18n.js | 5 yeni anahtar x 3 dil: yes, no, ng_q, m_ckpt, m_corrupt (43 anahtar, her dilde esit) |
| index.html | `#conf` onay penceresi eklendi |
| css/style.css | `#panel{z-index:8}`, `#conf{z-index:10}` + onay metni stili |
| package.json | `"test"` betigi eklendi (bagimlilik EKLENMEDI) |
| tests/a1.test.js | YENI: 40 kontrollu tarayici testi |

## Duzeltmeler
1. **Ayarlar paneli Pause ustunde:** tum ekranlar `z-index:5` idi; panel artik 8.
2. **Bozuk kayit/ayar:** `JSON.parse` korumasiz idi. Artik her okuma try/catch + sema dogrulama; gecersiz ayar degerleri sinirlandirilir; gecersiz kayit yok sayilir ve SILINMEZ (`dmla_save_bad` anahtarina yedeklenir). Erisilemeyen localStorage da cokertmez.
3. **Ses:** menuye donuste AudioContext kapatilir (yagmur/ruzgar/uğultu tamamen durur); oyuna donuste yeniden kurulur.
4. **Kapilar:** artik ~0.9 sn'de duvara KAYAN animasyon (eskiden gorunur kalip icinden geciliyordu). Carpisma kapinin anlik konumunu izler. Kayittan yuklenince kapi acik halde baslar.
5. **Yeni oyun onayi:** kayit varken YENI OYUN ve BOLUM SEC > Bolum 1 onay ister; HAYIR kaydi degistirmez. Yeni oyun ancak onaydan sonra ilk kaydi yazar.
6. **Restart:** gercek checkpoint anlik goruntusu (esyalar, kapilar, cozulen bulmacalar, pil, konum, bakis) kullanir. Checkpoint olaylari: yeni oyun, her esya alma, her kapi acma, sifre cozme. Eski formatli kayitlar (cp=dizi) otomatik uyarlanir.

## Bilerek DEGISTIRILMEYEN
Motor, shader, harita, hikaye metinleri, kontroller, kayit anahtar adlari (`dmla_save`, `dmla_set`), `window.__dmla` (test kancalari genisletildi).
