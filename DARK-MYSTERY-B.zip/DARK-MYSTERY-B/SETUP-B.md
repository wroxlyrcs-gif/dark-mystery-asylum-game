# Kurulum (yalnız telefonla)
GitHub web arayüzü ZIP açmaz; klasör yapısı bozulmamalı (özellikle `.github/workflows/android-build.yml` deponun KÖKÜNDE olmalı).

**Yol 1 – Termux (önerilen):** `pkg install git unzip` → depoyu `git clone` → ZIP'i depo içine açıp `DARK-MYSTERY-B/` İÇİNDEKİLERİ (gizli `.github` ve `.gitignore` dahil) depo köküne kopyala → `git add -A && git commit -m "B" && git push` (GitHub kişisel erişim jetonu ile). Commit/push'u sen yapıyorsun.
**Yol 2 – Tarayıcıda github.dev** (depoda `.` tuşu): dosyaları sürükle-bırak; gizli klasörler için masaüstü sitesi gerekebilir.

**APK alma:** GitHub → Actions → "Android Debug APK" → Run workflow (workflow dosyası varsayılan dalda olmalı) → bitince çalışmanın altındaki Artifacts → `app-debug` indir (içinde `app-debug.apk`). Telefonda "bilinmeyen kaynaklardan yükle" iznini ver. İlk çalışma 5–15 dk sürebilir. Hata olursa başarısız adımın günlüğünü bana gönder.
**İsteğe bağlı:** `android-project-source` artifact'ını açıp `android/` klasörünü depoya ekleyebilirsin (eklersen CI `cap add` adımını atlar, yama yine uygulanır).
