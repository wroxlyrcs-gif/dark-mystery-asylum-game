# Eksikler (B sonu)
- **APK üretilmedi** (ağ/SDK yok); ilk gerçek doğrulama GitHub Actions çalışmasıdır.
- `android/` projesi ve Gradle Wrapper ZIP'te yok; CI'da resmi şablondan üretilir.
- `package-lock.json` yok (npm erişimi yok) → CI `npm install` kullanır, Capacitor `^6` en güncel 6.x'e çözülür. İlk başarılı yerel/CI kurulumdan sonra lock dosyası eklenmesi önerilir.
- Gerçek Android cihaz testi yok.
- Release/imzalı APK yok (yalnız debug; anahtar/şifre eklenmedi).
- Oyun içeriği A2'deki gibi: yalnız Bölüm 1; Bölüm 2–5, bulmacaların çoğu, ses dosyaları (WebAudio sentezi), vb. sonraki aşamalar (C–G). Bu aşamada hikâye geliştirilmedi.
- Uygulama simgesi/açılış ekranı: Capacitor varsayılanı.
- INTERNET izni Capacitor şablonundan geliyor; oyun çevrimdışı çalışır, izin kaldırılmadı (riskli değişiklik yapılmadı).
