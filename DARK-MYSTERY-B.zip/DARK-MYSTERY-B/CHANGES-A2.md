# A2 degisiklik ozeti — kontrollu mimari duzenleme + 6 ek madde

Onceki durum: `dmla-A1.zip`. Tam fark: `A2.diff`. Davranis degisikligi YOKTUR (asagidaki maddeler disinda); A1'in 40 testi aynen gecer.

## Yeni dosyalar (game.js 17 KB -> 7 KB orkestra)
core/{dm,util,settings,save,audio,world,player,interact,input,ui}.js · render/renderer.js ·
data/{chapter1,items,docs,characters,quests}.js · js/i18n.js -> js/data/i18n.js (tasindi, icerik ayni) ·
tests/{a2.test.js, fixtures/*}  · CHANGES-A2.md

## Istenen 6 madde
1. **Pil=0 checkpoint/continue:** fener durumu kayitta tutulmaz, pilden TUREtilir (`DM.save.flashAfterRestore`): pil 0 -> kapali, >0 -> acik. Restart'ta mesaj "Kontrol noktasina donuldu. Pil bitti...". Not: A1'de de fener gorunur sekilde acilmiyordu (ana dongu ayni karede kapatiyordu); simdi kural acik, yukleme/continue/restart'ta uygulaniyor, dongudeki koruma ikinci katman olarak duruyor.
2. **Checkpoint tutarliligi:** konum, bakis, pil, envanter, kapilar, bulmacalar TEK anlik goruntude. Okumada onarim (ilerleme KAYBETTIRMEZ): envanterdeki esya "alindi" sayilir; acik kapinin anahtari/bulmacasi tamamlanir; pil 0-100; duvar icindeki konum baslangica alinir (kayit VE checkpoint icin).
3. **Menteseli kapi mimarisi:** `world.js > doorKinds` kayit defteri (`slide` kullanimda, `hinge` hazir+testli); renderer'da Y-ekseni `rot`+`piv`; carpisma donmus kutuyu bilir. Bolum 1 haritasi degismedi.
4. **`window.__dmla`:** yalnizca `DM.testMode` (=`?dmtest=1` ve Android/native DEGIL). Normal acilista tanimsiz.
5. **Geriye uyumluluk:** kayit sema v2; surumsuz (orijinal: `cp` dizi; A1: `cp` nesne) kayitlar otomatik yukseltilir. Gercek eski kayitlarla (tests/fixtures) test edildi. v>2 kayit reddedilir ve `dmla_save_bad`'e yedeklenir. Ayar anahtari/semasi degismedi.
6. **A1 testleri:** 40/40 yeniden calistirildi (tests/a1.test.js, yalniz URL'ye `?dmtest=1` eklendi).

## Bilerek DEGISTIRILMEDI
Motor/shader ciktisi (rot=0 iken ayni), harita, hikaye metinleri, kontroller, kayit anahtar adlari, i18n icerigi (5 A1 anahtari dahil 43/dil).
`data/characters.js` ve `data/quests.js` SIMDI kodda kullanilmiyor (A3 icin sema/kimlik).
