# B aşaması değişiklik raporu (A2 üzerine)

Taban: `dmla-A2.zip` (A2 mimarisi, 17 modül + game.js = 18 klasik JS, tek `DM` namespace, kendi WebGL motoru). Oyun tasarımı, hikâye, harita, kontroller DEĞİŞMEDİ.

## Değiştirilen / eklenen dosyalar
| Dosya | Tür | Neden |
|---|---|---|
| `build.js` | değişti | `assets/` yoksa çöküyordu. A2 ZIP'inde `assets/` BOŞ klasördü; Git boş klasörü izlemez → GitHub'da `npm run build` ENOENT ile kırılırdı (doğrulandı). Artık eksik `assets/` atlanır; `index.html/css/js` eksikse açık hata verir. |
| `capacitor.config.json` | değişti | `appName` → `DARK MYSTERY` (istenen ad); `backgroundColor:#000000` (açılışta beyaz parlama olmasın). appId, webDir, androidScheme (kayıtlar için sabit origin) aynı. |
| `js/game.js` | değişti (+~15 satır) | Android geri tuşu (en üst katmanı kapatır; oyunda duraklatma; ana menüde çıkış), arka plana geçince otomatik kayıt + duraklatma + ses askıya alma, Capacitor `App` eklentisi yokken sessiz atlama. Çıkış düğmesi aynı yardımcıyı kullanır. Yeni dosya EKLENMEDİ (18 JS korunur). `__dmla` test kancasına `back/hide/shown` eklendi (yalnız test modunda). |
| `scripts/patch-android.js` | YENİ | `npx cap add android` ile üretilen RESMİ Capacitor 6 şablonunu ayarlar: manifest `sensorLandscape`, uygulama adı, `MainActivity.java` (tam ekran immersive, ekran açık kalsın, çentik alanına çizim). Idempotent; başarısızlıkta build'i durdurur. |
| `.github/workflows/android-build.yml` | YENİ | Elle çalışan APK iş akışı (JDK 17, Node 18, npm install, build, cap add/patch/sync, gradle assembleDebug, APK varlık+boyut doğrulama, artifact `app-debug`). Üretilen `android/` projesi ayrıca `android-project-source` artifact'ı olarak da indirilebilir. |
| `package.json` | değişti | sürüm 0.2.0; `test` artık B testini de içerir; `android:patch` ve güncel `apk` betiği. Bağımlılıklar AYNI (4 Capacitor 6 paketi). |
| `.gitignore` | YENİ | node_modules, www, Gradle çıktıları. |
| `assets/.gitkeep` | YENİ | Boş klasör Git'te kalsın. |
| `tests/b.test.js` | YENİ | 61 kontrol (bkz. TEST-REPORT-B.md). |
| `README.md`, `CHANGES-B.md`, `TEST-REPORT-B.md`, `MISSING-FEATURES-B.md`, `SETUP-B.md` | belge | |

## `android/` klasörü neden ZIP'te yok?
Bu ortamda npm kayıt sunucusu, Google Maven, Gradle servisleri ve Maven Central'a erişim ve Android SDK yok (proxy 403). `npx cap add android` ve Gradle Wrapper bu yüzden burada ÜRETİLEMEDİ. Elle yazılmış, hiç derlenmemiş bir Android şablonu teslim etmek yerine, resmi şablon GitHub Actions içinde üretilir (ilk çalıştırmada), yamalanır ve derlenir. Üretilen proje `android-project-source` artifact'ı olarak indirilebilir; isterseniz depoya ekleyebilirsiniz.

## "DARK-MYSTERY-FINAL.zip" hakkında
İnceleme sonucu: boş iskelet (22 JS dosyası 28–69 bayt, oyun mantığı/render/kayıt/menü yok; Three.js yok; `.github/` altında proje kopyası; `webDir:"."`). Ana proje OLARAK KULLANILMADI; çalışan A2 korundu. Ondan alınanlar: Node 18, artifact adı `app-debug`.
