/* Game: orkestra. Durum makinesi (menu/play/ui), baslat/yukle/checkpoint-geri-yukle, ana dongu, dugme baglantilari.
   Mantik modullerde: player, input, ui, world, render, audio, save, settings, interact. Veri: js/data/*. */
(()=>{'use strict';
DM.need('settings','save','audio','world','render','player','input','ui','interact');
const $=id=>document.getElementById(id),cv=$('c');
const S=DM.settings.S,T=DM.settings.T,{nrm}=DM.util,{P,cam}=DM.player,{show,say}=DM.ui,{burst,creak,slam,step}=DM.audio;
const readSave=DM.save.read,validCp=DM.save.validCp,inp=DM.input.state;
DM.render.init(cv);
let G=null,mode='menu',boxes=[],objs=[],flash=true,ft=0,nextEv=0,evT=0,slamDone=false,tm=0,cur=null,padIn='',padObj=null;
const CH=DM.data.chapters[1];
DM.save.configure({rules:DM.world.rulesOf(CH),isBlocked:(x,z,g)=>DM.world.blockedAt(CH,x,z,g),spawn:CH.spawn});
const resize=()=>DM.render.resize(innerWidth,innerHeight,[.5,.75,1][S.q]*Math.min(devicePixelRatio||1,2));addEventListener('resize',resize);
const applyLang=()=>DM.ui.applyLang(()=>!!readSave());
const save=()=>DM.save.write(G,P,cam),checkpoint=()=>DM.save.checkpoint(G,P,cam);
function build(){const w=DM.world.build(CH,G);boxes=w.boxes;objs=w.objs}
function build0(){G={doors:{},picked:{},solved:{},items:[],battery:100};build();G=null}
function loading(fn){show('load');const b=$('lbar');b.style.width='20%';setTimeout(()=>{b.style.width='100%';setTimeout(fn,250)},150)}
/* Fener TASARIMI: durum kayitta tutulmaz; pilden turetilir (pil>0 => acik). Pil 0 ise fener kapali baslar, otomatik acilmaz. */
function start(load){const s=load?readSave():null;if(load&&!s){show('load',false);toMenu();say(T('m_corrupt'));return}
 DM.audio.init();DM.audio.resume();G=s||DM.save.create();
 build();DM.player.place(G.pos,G.yaw);flash=DM.save.flashAfterRestore(G);slamDone=!!load;evT=0;nextEv=20;mode='play';
 ['menu','panel','inv','doc','pad','pause','load'].forEach(i=>show(i,false));show('hud');applyLang();if(!load)save();
 try{screen.orientation.lock('landscape')}catch(e){}}
function restoreCheckpoint(){if(!G||!validCp(G.cp))return;show('pause',false);loading(()=>{const r=DM.save.applyCp(G,G.cp);
 build();DM.player.place(r.pos,r.yaw);flash=DM.save.flashAfterRestore(G);ft=0;evT=0;nextEv=20;slamDone=true;mode='play';
 show('load',false);show('hud');say(T('m_ckpt')+(flash?'':' '+T('m_dark')));save()})}
function toMenu(){DM.audio.stop();mode='menu';G=null;build0();['hud','pause','doc','inv','pad','panel'].forEach(i=>show(i,false));show('menu');applyLang()}
function newGameFlow(){const go=()=>{show('conf',false);show('menu',false);show('panel',false);loading(()=>start(false))};if(readSave())DM.ui.confirm('ng_q',go);else go()}
// ---------- etkilesim kurallari
function interact(){const o=cur;if(!o)return;
 if(o.t==='item'){G.picked[o.id]=true;o.b.p[1]=-9;G.items.push(o.id);say(T('m_pick')+T(o.id));burst(1500,.1,.3,'bandpass');checkpoint()}
 else if(o.t==='door'){if(o.lock==='key'&&!G.items.includes(o.key)){say(T('m_locked'));burst(400,.15,.4);return}
  if(o.lock==='code'&&!G.solved[o.puzzle]){say(T('m_locked'));return}
  if(o.lock==='key')say(T('m_unlock'));G.doors[o.id]=true;o.anim=0;creak();checkpoint()}
 else if(o.t==='pad'){if(G.solved[o.id])return say(T('m_ok'));padObj=o;padIn='';DM.ui.padText('----');mode='ui';show('pad')}
 else if(o.t==='end'){mode='ui';G.done1=true;save();$('dtext').textContent=T(DM.data.docs.end.textKey);show('doc')}}
DM.ui.buildKeypad(k=>{if(k==='C')padIn='';else if(k==='OK'){if(padObj&&padIn===padObj.code){G.solved[padObj.id]=true;say(T('m_ok'));mode='play';show('pad',false);checkpoint();burst(1800,.3,.3,'bandpass');return}else{say(T('m_wrong'));padIn='';burst(300,.3,.5)}}else if(padIn.length<4)padIn+=k;
 DM.ui.padText((padIn+'----').slice(0,4))});
const useBattery=()=>{G.battery=100;G.items.splice(G.items.indexOf('bat'),1);say(T('m_bat'));DM.ui.renderInventory(G,{useBattery})};
const toggleFlash=()=>{flash=!flash&&G.battery>0};
// ---------- ana dongu
let last=0;
function frame(ts){requestAnimationFrame(frame);const dt=Math.min((ts-last)/1000,.1);last=ts;tm+=dt;
 if(mode==='play'){for(const o of objs)if(o.t==='door'&&G.doors[o.id]&&o.anim<1){o.anim=Math.min(1,o.anim+dt/.9);DM.world.applyDoor(o)}
  DM.player.move(dt,inp,boxes);evT+=dt;
  if(!slamDone&&evT>5){slamDone=true;slam();say(T('m_slam'),5000);ft=1.2}
  if(evT>nextEv){nextEv=evT+20+Math.random()*25;ft=1;burst(500,.3,.5);setTimeout(step,900);setTimeout(step,1300)}
  if(flash){G.battery=Math.max(0,G.battery-dt*.35);if(G.battery<=0){flash=false;say(T('m_dark'))}}
  if(ft>0)ft-=dt;cur=DM.interact.nearest(objs,G,P,DM.player.fwd());show('bInt',!!cur);$('bat').textContent='🔋 '+Math.round(G.battery)+'%';
  if(Math.floor(tm)%20===0&&Math.abs(tm%1)<dt)save()}
 const f=DM.player.fwd(),fl=(flash&&mode!=='menu'?1:0)*(ft>0?(Math.sin(tm*60)>0?1:.1):1)*(G&&G.battery<15?(.6+.4*Math.sin(tm*25)):1);
 let e=P,fw=f;if(mode==='menu'){const a=tm*.08;e=[Math.sin(a)*.8,1.6,8+Math.sin(tm*.2)*3];fw=nrm([Math.sin(a*2)*.3,0,1])}
 if(!G&&!boxes.length)build0();
 DM.render.draw({eye:e,fwd:fw,fl:mode==='menu'?(Math.sin(tm*.7)>.6?.3:1):fl,amb:(.012+(Math.random()<.002?.25:0))*S.bri,bri:S.bri,t:tm,boxes})}
// ---------- baglantilar
DM.input.init({look:(dx,dy)=>DM.player.look(dx,dy,S.sens),isPlay:()=>mode==='play',interact,toggleFlash});
const pd={isMenu:()=>mode==='menu',newGame:newGameFlow,resize,applyLang};
$('bInt').onclick=interact;$('bFl').onclick=toggleFlash;
$('bInv').onclick=()=>{mode='ui';DM.ui.renderInventory(G,{useBattery});show('inv')};$('iClose').onclick=()=>{mode='play';show('inv',false);show('doc',false)};
$('dClose').onclick=()=>{show('doc',false);if(G.done1&&!$('inv').offsetParent)toMenu()};$('padClose').onclick=()=>{mode='play';show('pad',false)};
$('bPause').onclick=()=>{mode='ui';show('pause')};$('pRes').onclick=()=>{mode='play';show('pause',false)};
$('pRst').onclick=restoreCheckpoint;$('pMenu').onclick=()=>{save();toMenu()};$('pSet').onclick=()=>DM.ui.panel('set',pd);
$('bNew').onclick=newGameFlow;$('bCont').onclick=()=>{show('menu',false);loading(()=>start(true))};
// ---------- Android (B): Capacitor App eklentisi; tarayicida yoksa her sey sessizce atlanir
const nativeApp=()=>{const C=window.Capacitor;return C&&((C.Plugins&&C.Plugins.App)||(C.registerPlugin&&C.registerPlugin('App')))||null};
const vis=id=>!$(id).classList.contains('hid');
/* Geri tusu: en ustteki katmani kapatir; oyunda duraklatma acar; ana menude uygulamadan cikar. */
function backPressed(){
 if(vis('load'))return;if(vis('conf'))return show('conf',false);if(vis('panel'))return $('pBack').click();
 if(vis('doc'))return $('dClose').click();if(vis('pad'))return $('padClose').click();if(vis('inv'))return $('iClose').click();
 if(vis('pause'))return $('pRes').click();if(mode==='play')return $('bPause').click();if(mode==='menu')$('bExit').click()}
/* Arka plana gecis: kaydet, oyunu duraklat, sesi askiya al. Geri gelince ses devam eder (oyun duraklatma menusunde bekler). */
function appHidden(){if(mode==='play'){save();mode='ui';show('pause')}else if(G&&mode!=='menu')save();
 const c=DM.audio.ctx();if(c&&c.state==='running'){try{c.suspend()}catch(e){}}}
const appShown=()=>DM.audio.resume();
document.addEventListener('visibilitychange',()=>document.hidden?appHidden():appShown());
try{const A=nativeApp();if(A&&A.addListener){A.addListener('backButton',backPressed);A.addListener('appStateChange',s=>s.isActive?appShown():appHidden())}}catch(e){}
$('bExit').onclick=()=>{try{nativeApp().exitApp()}catch(e){}};
$('pBack').onclick=()=>{show('panel',false);if(mode==='menu')show('menu');DM.settings.save();applyLang()};
$('bSet').onclick=()=>DM.ui.panel('set',pd);$('bLang').onclick=()=>DM.ui.panel('lang',pd);$('bCred').onclick=()=>DM.ui.panel('cred',pd);$('bChap').onclick=()=>DM.ui.panel('chap',pd);
// ---------- acilis
resize();applyLang();build0();requestAnimationFrame(frame);setTimeout(()=>show('load',false),600);
// Test kancasi: YALNIZCA ?dmtest=1 ve Android-disi (bkz. core/dm.js). Normal calismada window.__dmla TANIMSIZDIR.
if(DM.testMode)window.__dmla={start,get G(){return G},get P(){return P},tp:(x,z)=>{P[0]=x;P[2]=z},interact,boxes:()=>boxes.length,boxesArr:()=>boxes,
 ctx:DM.audio.ctx,DM,cam,objs:()=>objs,get mode(){return mode},get S(){return S},get flash(){return flash},restore:restoreCheckpoint,back:backPressed,hide:appHidden,shown:appShown};
})();
