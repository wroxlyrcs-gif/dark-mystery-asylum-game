/* Karakter kayitlari — YALNIZCA kimlik alanlari (hikaye brifinden). Biyografiler Modul 05'te eklenecek. Henuz kodda kullanilmiyor. */
(function(DM){'use strict';
DM.data.characters={
 alex:{name:'Alex Morgan',age:24,role:'protagonist'},
 daniel:{name:'Daniel Cross',role:'patient047'},
 carter:{name:'Dr. William Carter',role:'chiefDoctor'},
 thomas:{name:'Thomas Morgan',role:'alexFather'}};
})(window.DM);
