/* Belge/metin kayitlari: textKey -> i18n anahtari. (A3'te yazar/tarih/Journal alanlari eklenecek) */
(function(DM){'use strict';
DM.data.docs={doc:{textKey:'d_doc'},end:{textKey:'m_end'}};
})(window.DM);
