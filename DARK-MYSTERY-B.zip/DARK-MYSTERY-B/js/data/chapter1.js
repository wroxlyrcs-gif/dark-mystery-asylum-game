/* BOLUM 1 HARITA VERISI (A1'deki build() fonksiyonundan birebir tasindi). Kod yok, yalnizca veri.
   Duvar: [x1,z1,x2,z2] (yukseklik 3). Kapi 'kind': 'slide' (duvara kayar) | 'hinge' (mentese, hazir ama bu haritada kullanilmiyor). */
(function(DM){'use strict';DM.data.chapters=DM.data.chapters||{};
DM.data.chapters[1]={id:1,spawn:[0,1.6,1.5],
 slabs:[{p:[0,-.1,12],s:[40,.2,40],c:[.28,.26,.24]},{p:[0,3.1,12],s:[40,.2,40],c:[.22,.21,.2]}],
 walls:[
  [-4,0,4,.2],[-4,0,-3.8,8],[3.8,0,4,8],[-4,8,-1.5,8.2],[1.5,8,4,8.2],               // giris holu
  [-1.6,8,-1.5,14.4],[-1.6,15.6,-1.5,20],[1.5,8,1.6,12.4],[1.5,13.6,1.6,20],          // koridor
  [-1.5,20,-.6,20.2],[.6,20,1.5,20.2],
  [1.5,10,7,10.2],[1.5,16,7,16.2],[6.8,10,7,16],                                      // resepsiyon
  [-7,12,-1.5,12.2],[-7,18,-1.5,18.2],[-7,12,-6.8,18],                                // ofis
  [-3,20,-.6,20.2],[.6,20,3,20.2],[-3,24.8,3,25],[-3,20,-2.8,25],[2.8,20,3,25]],      // son oda
 props:[
  {p:[4.5,.45,13],s:[1.8,.9,.8],c:[.3,.2,.12]},{p:[-4,.4,15],s:[1.5,.8,.8],c:[.25,.18,.1]},
  {p:[2.5,.3,3],s:[.8,.6,2],c:[.2,.2,.25]},{p:[-2.5,.5,6],s:[.6,1,.6],c:[.3,.15,.15]},
  {p:[0,1.5,1.5],s:[.1,.1,.1],c:[0,0,0],solid:false}],
 // lock: null | 'key' (key=esya id) | 'code' (puzzle=bulmaca id). slide: kapinin duvara kayma vektoru (metre).
 doors:[
  {id:'d_rec',x:1.55,z:13,w:.15,d:1.2,lock:null,kind:'slide',slide:[0,1.2]},
  {id:'d_off',x:-1.55,z:15,w:.15,d:1.2,lock:'key',key:'key',kind:'slide',slide:[0,1.2]},
  {id:'d_pad',x:0,z:20.1,w:1.2,d:.15,lock:'code',puzzle:'pad',kind:'slide',slide:[1.2,0]}],
 puzzles:[{id:'pad',type:'keypad',code:'4172',x:.45,z:19.9,r:2,light:{p:[.45,1.4,19.9],s:[.2,.3,.05]}}],
 items:[{id:'bat',x:-2.5,y:1.05,z:6,c:[.2,.8,.9]},{id:'key',x:4.5,y:.95,z:13,c:[.9,.8,.2]},{id:'doc',x:-4,y:.85,z:15,c:[.95,.95,.8]}],
 end:{x:0,z:23,r:1.4}};
})(window.DM);
