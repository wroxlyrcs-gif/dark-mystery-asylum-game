/* Esya katalogu. cat: kategori (A3'te envanter sekmeleri). read: belge metni anahtari (docs.js). use: 'battery' = fener pilini doldurur. */
(function(DM){'use strict';
DM.data.items={key:{cat:'keys'},bat:{cat:'tools',use:'battery'},doc:{cat:'documents',read:'doc'}};
})(window.DM);
