/* Gorev semasi (A3'te Quest Manager'a baglanacak; SIMDI kodda kullanilmiyor). A1'de oyunun kendiliginden izledigi Bolum 1 akisi:
   { id, chapter, titleKey, done: { picked|solved|door: id } } */
(function(DM){'use strict';
DM.data.quests={1:[
 {id:'q_bat',done:{picked:'bat'}},{id:'q_key',done:{picked:'key'}},{id:'q_office',done:{door:'d_off'}},
 {id:'q_doc',done:{picked:'doc'}},{id:'q_pad',done:{solved:'pad'}},{id:'q_end',done:{door:'d_pad'}}]};
})(window.DM);
