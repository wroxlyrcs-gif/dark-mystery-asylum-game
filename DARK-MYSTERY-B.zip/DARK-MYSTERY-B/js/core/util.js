(function(DM){'use strict';
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v);return true}catch(e){return false}}};
const jparse=x=>{try{return JSON.parse(x)}catch(e){return null}};
const num=(v,mn,mx,d)=>typeof v==='number'&&isFinite(v)?Math.min(mx,Math.max(mn,v)):d;
const isObj=x=>!!x&&typeof x==='object'&&!Array.isArray(x);
const okPos=a=>Array.isArray(a)&&a.length===3&&a.every(n=>typeof n==='number'&&isFinite(n));
const nrm=v=>{const l=Math.hypot(...v);return v.map(x=>x/l)},crs=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
DM.register('util',{store,jparse,num,isObj,okPos,nrm,crs,dot});
})(window.DM);
