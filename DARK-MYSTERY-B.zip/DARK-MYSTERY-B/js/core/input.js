/* Input Manager: dokunmatik joystick + kamera, fare, klavye, kosma. Oyun mantigini bilmez; h geri cagrilariyla haberlesir. */
(function(DM){'use strict';const $=id=>document.getElementById(id);
const joy={x:0,y:0},keys={},inp={joy,keys,run:false};
function tch(el,on,mv,off){el.addEventListener('touchstart',e=>{e.preventDefault();for(const t of e.changedTouches)on(t,el)},{passive:false});
 el.addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches)mv(t,el)},{passive:false});
 el.addEventListener('touchend',e=>{for(const t of e.changedTouches)off(t)});el.addEventListener('touchcancel',e=>{for(const t of e.changedTouches)off(t)})}
function init(h){let jid=null,lid=null,lx=0,ly=0;
 function jm(t){const r=$('joy').getBoundingClientRect(),R=r.width/2;let dx=t.clientX-r.left-R,dy=t.clientY-r.top-R;const l=Math.hypot(dx,dy);if(l>R){dx*=R/l;dy*=R/l}joy.x=dx/R;joy.y=dy/R;$('knob').style.transform=`translate(${dx}px,${dy}px)`}
 tch($('joy'),t=>{jid=t.identifier;jm(t)},t=>{if(t.identifier===jid)jm(t)},t=>{if(t.identifier===jid){jid=null;joy.x=joy.y=0;$('knob').style.transform=''}});
 tch($('look'),t=>{lid=t.identifier;lx=t.clientX;ly=t.clientY},t=>{if(t.identifier===lid){h.look(t.clientX-lx,t.clientY-ly);lx=t.clientX;ly=t.clientY}},t=>{if(t.identifier===lid)lid=null});
 let md=false;$('look').addEventListener('mousedown',e=>{md=true;lx=e.clientX;ly=e.clientY});addEventListener('mouseup',()=>md=false);
 addEventListener('mousemove',e=>{if(md&&h.isPlay()){h.look(e.clientX-lx,e.clientY-ly);lx=e.clientX;ly=e.clientY}});
 addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=1;if(h.isPlay()){if(e.key==='e')h.interact();if(e.key==='f')h.toggleFlash()}});addEventListener('keyup',e=>keys[e.key.toLowerCase()]=0);
 $('bRun').ontouchstart=e=>{e.preventDefault();inp.run=true};$('bRun').ontouchend=()=>inp.run=false;$('bRun').onmousedown=()=>inp.run=true;$('bRun').onmouseup=()=>inp.run=false}
DM.register('input',{init,state:inp});
})(window.DM);
