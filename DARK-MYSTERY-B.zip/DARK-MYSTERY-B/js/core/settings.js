/* Ayarlar + dil (Language Manager). S nesnesi tek ve kalicidir; her yerde ayni referans kullanilir. */
(function(DM){'use strict';DM.need('util');const {store,jparse,num,isObj}=DM.util;
function clean(o){o=isObj(o)?o:{};return{lang:['tr','en','ru'].includes(o.lang)?o.lang:'tr',vol:num(o.vol,0,1,.7),sens:num(o.sens,.3,2.5,1),q:[0,1,2].includes(o.q)?o.q:2,bri:num(o.bri,.6,2,1)}}
const S=clean(jparse(store.get('dmla_set')));
const T=k=>(window.I18N[S.lang]||window.I18N.tr)[k]||k;
DM.register('settings',{S,T,clean,save:()=>store.set('dmla_set',JSON.stringify(S))});
})(window.DM);
