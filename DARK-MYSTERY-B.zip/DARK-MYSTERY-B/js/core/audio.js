/* Audio Manager: WebAudio sentezi (ses dosyasi yok). stop() baglami KAPATIR -> yagmur/ruzgar tamamen durur. */
(function(DM){'use strict';DM.need('settings');const S=DM.settings.S;let ctx=null,master=null;
function init(){if(ctx)return;try{ctx=new(window.AudioContext||window.webkitAudioContext)();master=ctx.createGain();master.connect(ctx.destination);setVol();
 const nb=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate),d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;ctx.nb=nb;
 const r=ctx.createBufferSource();r.buffer=nb;r.loop=true;const hp=ctx.createBiquadFilter();hp.type='highpass';hp.frequency.value=2500;const g=ctx.createGain();g.gain.value=.06;r.connect(hp);hp.connect(g);g.connect(master);r.start();
 const w=ctx.createBufferSource();w.buffer=nb;w.loop=true;const bp=ctx.createBiquadFilter();bp.type='lowpass';bp.frequency.value=300;const wg=ctx.createGain();wg.gain.value=.12;w.connect(bp);bp.connect(wg);wg.connect(master);w.start();
 const o=ctx.createOscillator();o.frequency.value=48;const og=ctx.createGain();og.gain.value=.05;o.connect(og);og.connect(master);o.start()}catch(e){ctx=null;master=null}}
function stop(){if(ctx){try{ctx.close()}catch(e){}}ctx=null;master=null}
function resume(){if(ctx&&ctx.state==='suspended')ctx.resume()}
function setVol(){if(master)master.gain.value=S.vol}
function burst(f,dur,vol,type='lowpass'){if(!ctx)return;const s=ctx.createBufferSource();s.buffer=ctx.nb;const fl=ctx.createBiquadFilter();fl.type=type;fl.frequency.value=f;const g=ctx.createGain();g.gain.setValueAtTime(vol,ctx.currentTime);g.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+dur);s.connect(fl);fl.connect(g);g.connect(master);s.start();s.stop(ctx.currentTime+dur)}
function creak(){if(!ctx)return;const o=ctx.createOscillator();o.type='sawtooth';o.frequency.setValueAtTime(220,ctx.currentTime);o.frequency.exponentialRampToValueAtTime(70,ctx.currentTime+.9);const g=ctx.createGain();g.gain.value=.05;g.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+.9);o.connect(g);g.connect(master);o.start();o.stop(ctx.currentTime+.9)}
DM.register('audio',{init,stop,resume,setVol,burst,creak,slam:()=>burst(180,.8,.9),step:()=>burst(220,.12,.25),ctx:()=>ctx});
})(window.DM);
