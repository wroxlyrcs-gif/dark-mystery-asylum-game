/* Player Controller + Camera Controller: konum P ve bakis cam TEK referanstir (yerinde degisir; diger moduller bu referanslari tutar). */
(function(DM){'use strict';DM.need('world','audio');
const P=[0,1.6,1.5],cam={yaw:0,pitch:0};let bob=0,stepD=0;
const fwd=()=>{const cp=Math.cos(cam.pitch);return[Math.sin(cam.yaw)*cp,Math.sin(cam.pitch),Math.cos(cam.yaw)*cp]};
function place(pos,yaw){P[0]=pos[0];P[1]=pos[1];P[2]=pos[2];cam.yaw=yaw||0;cam.pitch=0}
function look(dx,dy,sens){cam.yaw-=dx*.005*sens;cam.pitch=Math.max(-1.3,Math.min(1.3,cam.pitch-dy*.005*sens))}
function try1(boxes,dx,dz){const x=P[0]+dx,z=P[2]+dz;if(DM.world.collides(boxes,x,z,DM.world.RAD))return;P[0]=x;P[2]=z}
function move(dt,inp,boxes){const k=inp.keys,run=inp.run;let sx=inp.joy.x+(k.d?1:0)-(k.a?1:0),sz=-inp.joy.y+(k.w?1:0)-(k.s?1:0);const m=Math.hypot(sx,sz);if(m>1){sx/=m;sz/=m}
 const sp=(run||k.shift?3.6:2.1)*dt,y=cam.yaw,fx=Math.sin(y),fz=Math.cos(y),rx=-Math.cos(y),rz=Math.sin(y);
 const dx=(fx*sz+rx*sx)*sp,dz=(fz*sz+rz*sx)*sp;try1(boxes,dx,0);try1(boxes,0,dz);
 if(m>.1){bob+=dt*(run?11:7);stepD+=sp;if(stepD>1){stepD=0;DM.audio.step()}}
 P[1]=1.6+Math.sin(bob)*.04}
DM.register('player',{P,cam,fwd,place,look,move});
})(window.DM);
