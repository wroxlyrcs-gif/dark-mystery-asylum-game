/* UI Manager: ekran gosterme, mesaj, dil uygulama, ayar/dil/bolum panelleri, envanter listesi, sifre tusu, onay penceresi. */
(function(DM){'use strict';DM.need('settings');const S=DM.settings.S,T=DM.settings.T,saveSet=DM.settings.save;const $=id=>document.getElementById(id);let msgT=0;
const show=(id,v=true)=>$(id).classList.toggle('hid',!v);
function say(t,ms=3500){const m=$('msg');m.textContent=t;m.style.opacity=1;clearTimeout(msgT);msgT=setTimeout(()=>m.style.opacity=0,ms)}
function applyLang(canContinue){document.querySelectorAll('[data-i]').forEach(e=>e.textContent=T(e.dataset.i));document.documentElement.lang=S.lang;
 $('bCont').disabled=!canContinue();$('bExit').style.display=window.Capacitor?'':'none'}
function buildKeypad(onKey){const kb=$('keys');kb.innerHTML='';[1,2,3,4,5,6,7,8,9,'C',0,'OK'].forEach(k=>{const b=document.createElement('button');b.textContent=k;b.onclick=()=>onKey(k);kb.appendChild(b)})}
const padText=t=>{$('disp').textContent=t};
function renderInventory(G,cb){const l=$('ilist');l.innerHTML='';const c={};G.items.forEach(i=>c[i]=(c[i]||0)+1);
 if(!G.items.length)l.textContent='—';for(const i in c){const b=document.createElement('button');b.textContent=T(i)+' x'+c[i];
  b.onclick=()=>{const it=DM.data.items[i]||{};if(it.read){$('dtext').textContent=T(DM.data.docs[it.read].textKey);show('doc')}else if(it.use==='battery')cb.useBattery()};l.appendChild(b)}}
function confirm(textKey,yes){$('cText').textContent=T(textKey);$('cYes').onclick=yes;$('cNo').onclick=()=>show('conf',false);show('conf')}
/* d: {isMenu(), newGame(), resize(), applyLang()} */
function panel(k,d){show('panel');if(d.isMenu())show('menu',false);const b=$('pbody');b.innerHTML='';
 const row=(l,el)=>{const x=document.createElement('label');x.append(l,el);b.append(x);return el};
 const rng=(key,mn,mx,st)=>{const i=document.createElement('input');i.type='range';i.min=mn;i.max=mx;i.step=st;i.value=S[key];i.oninput=()=>{S[key]=+i.value;DM.audio.setVol();saveSet()};return i};
 if(k==='set'){row(T('vol'),rng('vol',0,1,.05));row(T('sens'),rng('sens',.3,2.5,.1));row(T('bright'),rng('bri',.6,2,.1));
  const q=document.createElement('select');[['low',0],['med',1],['high',2]].forEach(([n,v])=>q.add(new Option(T(n),v)));q.value=S.q;q.onchange=()=>{S.q=+q.value;d.resize();saveSet()};row(T('qual'),q)}
 else if(k==='lang'){['tr','en','ru'].forEach(l=>{const x=document.createElement('button');x.textContent={tr:'Türkçe',en:'English',ru:'Русский'}[l];x.onclick=()=>{S.lang=l;saveSet();d.applyLang();panel('lang',d)};b.append(x)})}
 else if(k==='cred'){b.textContent=T('credits');b.style.whiteSpace='pre-line';b.style.textAlign='center'}
 else if(k==='chap'){for(let i=1;i<=5;i++){const x=document.createElement('button');x.textContent='CHAPTER '+i+(i>1?' — '+T('locked'):'');x.disabled=i>1;if(i===1)x.onclick=d.newGame;b.append(x)}}}
DM.register('ui',{show,say,applyLang,buildKeypad,padText,renderInventory,confirm,panel});
})(window.DM);
