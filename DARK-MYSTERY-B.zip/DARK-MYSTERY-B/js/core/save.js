/* Save Manager: kayit semasi (v2), eski kayit goci, tutarlilik onarimi, checkpoint.
   Depolama anahtari degismedi: dmla_save. Gecersiz kayit SILINMEZ -> dmla_save_bad. */
(function(DM){'use strict';DM.need('util');const {store,jparse,num,isObj,okPos}=DM.util;
const SCHEMA=2,KEY='dmla_save',BAD='dmla_save_bad';
let env={rules:{doors:[]},isBlocked:()=>false,spawn:[0,1.6,1.5]};
const configure=e=>{env=Object.assign(env,e)};
const snap=(g,pos,yaw)=>({pos:[...pos],yaw:yaw||0,doors:{...g.doors},picked:{...g.picked},solved:{...g.solved},items:[...g.items],battery:g.battery});
const validCp=c=>isObj(c)&&okPos(c.pos)&&isObj(c.doors)&&isObj(c.picked)&&isObj(c.solved)&&Array.isArray(c.items)&&c.items.every(i=>typeof i==='string')&&typeof c.battery==='number';
const validShape=s=>isObj(s)&&isObj(s.doors)&&isObj(s.picked)&&isObj(s.solved)&&Array.isArray(s.items)&&s.items.every(i=>typeof i==='string')&&okPos(s.pos)&&typeof s.battery==='number'&&isFinite(s.battery);
const create=()=>{const g={v:SCHEMA,ch:1,items:[],doors:{},picked:{},solved:{},pos:[...env.spawn],yaw:0,battery:100};g.cp=snap(g,g.pos,0);return g};
/* Tutarlilik: ILERLEME KAYBETTIRMEZ, eksik onkosulu tamamlar.
   (1) envanterdeki her esya "alindi" sayilir  (2) acik kapinin anahtari/bulmacasi tamam sayilir
   (3) pil 0-100  (4) konum duvarin/kapali kapinin icindeyse baslangica alinir */
function normalize(g){const n=[];g.battery=num(g.battery,0,100,100);g.yaw=num(g.yaw,-1e4,1e4,0);
 for(const i of g.items)if(!g.picked[i]){g.picked[i]=true;n.push('picked:'+i)}
 for(const d of env.rules.doors){if(!g.doors[d.id])continue;
  if(d.key&&!g.picked[d.key]){g.picked[d.key]=true;if(!g.items.includes(d.key))g.items.push(d.key);n.push('key:'+d.key)}
  if(d.puzzle&&!g.solved[d.puzzle]){g.solved[d.puzzle]=true;n.push('puzzle:'+d.puzzle)}}
 if(env.isBlocked(g.pos[0],g.pos[2],g)){g.pos=[...env.spawn];n.push('pos')}return n}
function migrate(s){if(!isObj(s))return null;const v=s.v===undefined?1:s.v;if(typeof v!=='number'||v>SCHEMA)return null;   // gelecek surum: reddet (yedeklenir)
 if(!validShape(s))return null;if(!validCp(s.cp))s.cp=snap(s,s.pos,s.yaw);s.v=SCHEMA;return s}   // v1 (orijinal: cp dizi, A1: surumsuz) -> v2
function read(){const raw=store.get(KEY);if(raw===null)return null;const s=migrate(jparse(raw));if(!s){store.set(BAD,raw);return null}
 normalize(s);s.cp.yaw=num(s.cp.yaw,-1e4,1e4,0);normalize(s.cp);return s}
function write(g,P,cam){if(!g)return false;g.v=SCHEMA;g.pos=[...P];g.yaw=cam.yaw;return store.set(KEY,JSON.stringify(g))}
function checkpoint(g,P,cam){if(!g)return;g.cp=snap(g,[P[0],1.6,P[2]],cam.yaw);write(g,P,cam)}
/* Checkpoint'i canli duruma uygular; konum/bakisi dondurur. Pil/fener kurali icin bkz. DM.save.flashAfterRestore */
function applyCp(g,c){g.doors={...c.doors};g.picked={...c.picked};g.solved={...c.solved};g.items=[...c.items];g.battery=c.battery;g.done1=false;return{pos:[...c.pos],yaw:c.yaw||0}}
/* TASARIM KURALI: fener durumu kayitta tutulmaz, pilden TUREtilir. Pil 0 ise fener kapali dogar; pil varsa acik. */
const flashAfterRestore=g=>g.battery>0;
DM.register('save',{SCHEMA,KEY,BAD,configure,create,snap,validCp,validShape,normalize,migrate,read,write,checkpoint,applyCp,flashAfterRestore});
})(window.DM);
