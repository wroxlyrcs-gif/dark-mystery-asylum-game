/* Interaction Manager: bakilan/yakin etkilesim nesnesini bulur (saf fonksiyon; kurallari game.js uygular, A3'te Quest Manager'a baglanir). */
(function(DM){'use strict';
function nearest(objs,G,P,f){let best=null,bd=9;for(const o of objs){if(o.t==='item'&&G.picked[o.id])continue;if(o.t==='door'&&G.doors[o.id])continue;
 const dx=o.pos[0]-P[0],dz=o.pos[1]-P[2],d=Math.hypot(dx,dz);if(d>o.r||(o.t!=='end'&&d>.8&&(dx*f[0]+dz*f[2])/d<.45))continue;if(d<bd){bd=d;best=o}}return best}
DM.register('interact',{nearest});
})(window.DM);
