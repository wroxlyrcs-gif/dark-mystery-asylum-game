/* DM: tek global isim alani. Moduller DM.register(ad, nesne) ile kaydolur.
   Klasik <script> kullanilir (ES module degil) -> index.html dogrudan Chrome'da da, Capacitor'da da calisir; derleme adimi yok. */
(function(){'use strict';
const native=!!(window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform());
const DM=window.DM={
 version:'A2',
 data:{},                                   // veri dosyalari buraya yazar (js/data/*)
 // Test kancalari YALNIZCA ?dmtest=1 ile ve yerel (Android disi) calisirken acilir. APK'da asla.
 testMode:!native&&/[?&]dmtest(=1)?(&|$)/.test(location.search),
 register(name,mod){if(DM[name])throw new Error('DM modulu zaten kayitli: '+name);DM[name]=mod;return mod},
 need(...names){for(const n of names)if(!DM[n])throw new Error('DM modulu eksik: '+n+' (index.html script sirasini kontrol edin)')}
};})();
