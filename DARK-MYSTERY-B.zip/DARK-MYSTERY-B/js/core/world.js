/* World + Door Manager: veriden (data/chapterN.js) kutu dunyasi uretir, kapi turlerini ve carpismayi yonetir.
   Kapi turleri KAYIT DEFTERIdir (doorKinds): yeni tur eklemek = tek bir apply() yazmak. 'hinge' (mentese) HAZIR ve test edilmis,
   ama Bolum 1 haritasi kullanmiyor. Renderer b.rot/b.piv'i (Y ekseni, pivot noktasi) destekler; carpisma da donmus kutuyu bilir. */
(function(DM){'use strict';DM.need('util');const RAD=.3;
const mk=o=>({p:[...o.p],s:[...o.s],c:[...o.c],solid:o.solid!==false,em:o.em||0,lift:0,off:[0,0],rot:0,piv:[0,0,0]});
const doorKinds={
 slide:{apply(o,e){const s=o.def.slide||(o.def.w>o.def.d?[o.def.w,0]:[0,o.def.d]);o.b.off=[s[0]*e,s[1]*e]}},
 hinge:{apply(o,e){const h=o.def.hinge;o.b.piv=[h.pivot[0],0,h.pivot[1]];o.b.rot=h.angle*e}}};   // def.hinge={pivot:[x,z],angle:radyan}
function applyDoor(o){const e=o.anim*o.anim*(3-2*o.anim);(doorKinds[o.kind]||doorKinds.slide).apply(o,e)}
function build(ch,G){const boxes=[],objs=[],B=o=>{const b=mk(o);boxes.push(b);return b};
 for(const s of ch.slabs)B({p:s.p,s:s.s,c:s.c,solid:false});
 for(const [x1,z1,x2,z2] of ch.walls)B({p:[(x1+x2)/2,1.5,(z1+z2)/2],s:[Math.max(.2,x2-x1),3,Math.max(.2,z2-z1)],c:[.45,.42,.38]});
 for(const p of ch.props)B(p);
 for(const d of ch.doors){const b=B({p:[d.x,1.3,d.z],s:[d.w,2.6,d.d],c:[.3,.2,.12]});objs.push({id:d.id,t:'door',b,lock:d.lock||null,key:d.key,puzzle:d.puzzle,pos:[d.x,d.z],r:2.2,kind:d.kind||'slide',def:d,anim:0})}
 for(const q of ch.puzzles){B({p:q.light.p,s:q.light.s,c:[.2,.9,.3],solid:false,em:1.2});objs.push({id:q.id,t:'pad',pos:[q.x,q.z],r:q.r,code:q.code})}
 for(const i of ch.items){const b=B({p:[i.x,i.y,i.z],s:[.22,.1,.22],c:i.c,solid:false,em:1.4});objs.push({id:i.id,t:'item',b,pos:[i.x,i.z],r:1.8})}
 objs.push({id:'end',t:'end',pos:[ch.end.x,ch.end.z],r:ch.end.r});
 for(const o of objs){if(o.t==='door'&&G.doors[o.id]){o.anim=1;applyDoor(o)}if(o.t==='item'&&G.picked[o.id])o.b.p[1]=-9}
 return{boxes,objs}}
function collides(boxes,x,z,r){for(const b of boxes){if(!b.solid)continue;
 const bx=b.p[0]+b.off[0],bz=b.p[2]+b.off[1];let px=x,pz=z;
 if(b.rot){const c=Math.cos(-b.rot),s=Math.sin(-b.rot),dx=x-b.piv[0],dz=z-b.piv[2];px=b.piv[0]+dx*c+dz*s;pz=b.piv[2]-dx*s+dz*c}   // oyuncuyu kapinin yerel eksenine cevir
 if(px>bx-b.s[0]/2-r&&px<bx+b.s[0]/2+r&&pz>bz-b.s[2]/2-r&&pz<bz+b.s[2]/2+r)return true}return false}
const blockedAt=(ch,x,z,g)=>collides(build(ch,{doors:g.doors||{},picked:g.picked||{}}).boxes,x,z,RAD);
const rulesOf=ch=>({doors:ch.doors.filter(d=>d.key||d.puzzle).map(d=>({id:d.id,key:d.key,puzzle:d.puzzle}))});
DM.register('world',{RAD,doorKinds,applyDoor,build,collides,blockedAt,rulesOf});
})(window.DM);
