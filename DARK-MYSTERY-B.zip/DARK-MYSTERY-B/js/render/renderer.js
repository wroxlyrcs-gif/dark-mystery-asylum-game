/* Renderer: ozel WebGL motoru (A1'deki shader/geometri AYNEN; tek ekleme: kutu basina Y-ekseni donusu rot + pivot piv).
   rot=0 iken ciktisi eskisiyle aynidir. Menteseli kapi = rot!=0 ve piv=menteșe noktasi (bkz. world.js doorKinds.hinge). */
(function(DM){'use strict';DM.need('util');const {nrm,crs,dot}=DM.util;let gl,cv,pr;const U={};
const VS=`attribute vec3 p,n;uniform mat4 vp;uniform vec3 pos,size,piv;uniform float rot;varying vec3 wp,wn;void main(){vec3 w=p*size+pos;vec3 nn=n;if(rot!=0.){float c=cos(rot),s=sin(rot);vec3 d=w-piv;w=piv+vec3(d.x*c+d.z*s,d.y,-d.x*s+d.z*c);nn=vec3(n.x*c+n.z*s,n.y,-n.x*s+n.z*c);}wp=w;wn=nn;gl_Position=vp*vec4(wp,1.);}`;
const FS=`precision mediump float;varying vec3 wp,wn;uniform vec3 col,cam,fwd;uniform float em,fl,amb,bri,t;
float h(vec3 q){return fract(sin(dot(q,vec3(12.9,78.2,37.7)))*43758.5);}
void main(){vec3 q=floor(wp*5.);float g=h(q)*.5+h(floor(wp*1.3))*.5;vec3 c=col*(.55+.6*g);
vec3 L=cam-wp;float d=length(L);L/=d;float sp=smoothstep(.80,.93,dot(L,-fwd));
float lit=amb+fl*sp*max(dot(wn,L),0.)*1.7/(1.+.12*d*d);
vec3 o=c*lit+col*em*(.6+.4*sin(t*3.));o*=bri;o*=exp(-d*.06);gl_FragColor=vec4(sqrt(o),1.);}`;
function sh(t,s){const x=gl.createShader(t);gl.shaderSource(x,s);gl.compileShader(x);if(!gl.getShaderParameter(x,gl.COMPILE_STATUS))throw gl.getShaderInfoLog(x);return x}
function init(canvas){cv=canvas;gl=cv.getContext('webgl',{antialias:false});if(!gl)throw new Error('WebGL desteklenmiyor');
 pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pr);gl.useProgram(pr);
 ['vp','pos','size','piv','rot','col','cam','fwd','em','fl','amb','bri','t'].forEach(k=>U[k]=gl.getUniformLocation(pr,k));
 const F=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],a=[];
 for(const f of F){const u=f[1]?[1,0,0]:[0,1,0],v=[f[1]*u[2]-f[2]*u[1],f[2]*u[0]-f[0]*u[2],f[0]*u[1]-f[1]*u[0]];
  const c=(s,t)=>[0,1,2].map(i=>f[i]*.5+u[i]*s*.5+v[i]*t*.5);
  for(const [s,t] of [[-1,-1],[1,-1],[1,1],[-1,-1],[1,1],[-1,1]])a.push(...c(s,t),...f)}
 gl.bindBuffer(gl.ARRAY_BUFFER,gl.createBuffer());gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(a),gl.STATIC_DRAW);
 for(const [k,o] of [['p',0],['n',12]]){const l=gl.getAttribLocation(pr,k);gl.enableVertexAttribArray(l);gl.vertexAttribPointer(l,3,gl.FLOAT,false,24,o)}
 gl.enable(gl.DEPTH_TEST)}
function resize(w,h,scale){cv.width=w*scale;cv.height=h*scale;gl.viewport(0,0,cv.width,cv.height)}
function VP(e,f){const s=nrm(crs(f,[0,1,0])),u=crs(s,f),a=cv.width/cv.height,fv=1.25,n=.05,fa=60,k=1/Math.tan(fv/2);
 const V=[s[0],u[0],-f[0],0,s[1],u[1],-f[1],0,s[2],u[2],-f[2],0,-dot(s,e),-dot(u,e),dot(f,e),1];
 const P=[k/a,0,0,0,0,k,0,0,0,0,(fa+n)/(n-fa),-1,0,0,2*fa*n/(n-fa),0],M=new Array(16);
 for(let c=0;c<4;c++)for(let r=0;r<4;r++){let x=0;for(let i=0;i<4;i++)x+=P[i*4+r]*V[c*4+i];M[c*4+r]=x}return M}
/* fr: {eye,fwd,fl,amb,bri,t,boxes} */
function draw(fr){gl.clearColor(.01,.01,.015,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 gl.uniformMatrix4fv(U.vp,false,VP(fr.eye,fr.fwd));gl.uniform3fv(U.cam,fr.eye);gl.uniform3fv(U.fwd,fr.fwd);
 gl.uniform1f(U.fl,fr.fl);gl.uniform1f(U.amb,fr.amb);gl.uniform1f(U.bri,fr.bri);gl.uniform1f(U.t,fr.t);
 for(const b of fr.boxes){const o=b.off||[0,0];gl.uniform3f(U.pos,b.p[0]+o[0],b.p[1]+b.lift,b.p[2]+o[1]);gl.uniform3fv(U.size,b.s);gl.uniform3fv(U.col,b.c);gl.uniform1f(U.em,b.em);
  gl.uniform1f(U.rot,b.rot||0);gl.uniform3fv(U.piv,b.piv||[0,0,0]);gl.drawArrays(gl.TRIANGLES,0,36)}}
DM.register('render',{init,resize,draw,VP,uniforms:()=>U});
})(window.DM);
