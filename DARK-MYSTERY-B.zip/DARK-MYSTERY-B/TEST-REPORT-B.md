# B aşaması test raporu

**Ortam:** Linux sandbox, Node 22, Playwright Chromium (SwiftShader). **Gerçek Android cihaz/emülatör testi YAPILMADI. APK ÜRETİLMEDİ.** Chromium testleri Android testi yerine geçmez.

| Paket | Sonuç | Kapsam |
|---|---|---|
| `tests/a1.test.js` | 40/40 | Menü, yeni oyun, kayıt/continue, kapılar, bulmaca, dokunmatik joystick+kamera |
| `tests/a2.test.js` | 43/43 | Modüller, checkpoint tutarlılığı, eski kayıt göçü, menteşe kapı, test kancası |
| `tests/b.test.js` | 61/61 | Aşağıda |
| `node --check` | tüm js/scripts/tests geçti | sözdizimi |

Not: önceki raporda belirtilen sayılar (15/15, 67/67, 19/19) ZIP'teki testlerle eşleşmiyor; burada ölçülen gerçek değerler 40/40 ve 43/43'tür.

## b.test.js kapsamı
- **Statik:** capacitor.config (appId/appName/webDir), 4 Capacitor 6.x bağımlılığı (başka kütüphane yok), `build.js` assets/ olmadan çalışıyor, www/js = 18 dosya, workflow adımları + sırası + YAML geçerliliği, Node 18.
- **Android yaması (Capacitor 6 şablonunu TAKLİT eden sahte iskelet üzerinde):** manifest sensorLandscape, configChanges/provider korunuyor, uygulama adı, MainActivity.java içeriği, idempotent, android/ yoksa hata. Gerçek şablon üzerinde denenmedi.
- **Chromium (844×390 yatay, dokunmatik, SAHTE Capacitor):** yatay ekran; menü; 3 dil (TR/EN/RU) etiketleri; Ayarlar; New Game; Continue; etkileşim düğmesi (dokunma); fener düğmesi; envanter; geri tuşu (ayarlar/envanter/duraklatma/oyun/ana menü-çıkış); arka plana geçişte otomatik duraklatma + kayıt + ses askıya alma, dönüşte ses devam; internet dışı istek YOK; JS hatası YOK; native modda test kancası kapalı.
- **MainActivity.java:** `javac` ile yalnızca sözdizimi kontrolü (Android kütüphaneleri olmadığından sembol hataları beklenen; sözdizimi hatası yok). API uyumu DOĞRULANMADI.

## DOĞRULANMAMIŞ (gerçek derleme/cihaz gerekir)
APK oluşumu, Gradle/AGP/SDK uyumu, JDK 17 ile derleme, `cap add android` + yamanın gerçek şablonla uyumu, gerçek WebView'da WebGL/ses/dokunma, `Capacitor.Plugins.App` erişimi (yoksa `registerPlugin('App')` yedeği var; ikisi de olmazsa geri tuşu Capacitor varsayılanına düşer), immersive/çentik davranışı, performans, "Çıkış" düğmesi, offline açılış (yalnızca "dış istek yok" doğrulandı).
