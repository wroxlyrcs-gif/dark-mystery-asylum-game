// B asamasi testi: Android altyapisi (statik) + geri tusu/arka plan (Chromium, SAHTE Capacitor ile) + A2 ozelliklerinin Android-benzeri ekranda calismasi.
// UYARI: Bu testler Chromium'da calisir. GERCEK Android cihaz/emulator testi DEGILDIR.
// Calistirma: PW_PATH=<playwright yolu> node tests/b.test.js
const path=require('path'),fs=require('fs'),os=require('os'),http=require('http'),cp=require('child_process');
const {chromium}=require(process.env.PW_PATH||'playwright');
const root=path.join(__dirname,'..'),M={'.html':'text/html','.js':'text/javascript','.css':'text/css'};
let pass=0,fail=0;const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS  ':'FAIL  ')+n)};
const sl=ms=>new Promise(r=>setTimeout(r,ms));
const rd=f=>fs.readFileSync(path.join(root,f),'utf8');
(async()=>{
 // ===== STATIK: yapilandirma
 const cfg=JSON.parse(rd('capacitor.config.json')),pkg=JSON.parse(rd('package.json'));
 ok(cfg.appId==='com.darkmystery.lostasylum'&&cfg.appName==='DARK MYSTERY'&&cfg.webDir==='www','capacitor.config: appId, appName=DARK MYSTERY, webDir=www');
 const dep=Object.assign({},pkg.dependencies,pkg.devDependencies);
 ok(['@capacitor/core','@capacitor/android','@capacitor/app','@capacitor/cli'].every(k=>/^\^6\./.test(dep[k])),'Capacitor paketleri 6.x');
 ok(Object.keys(dep).length===4,'Gereksiz kutuphane yok (yalniz 4 Capacitor paketi)');
 // build: assets/ olmadan da calismali (Git bos klasoru izlemez)
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'dmb-'));
 for(const f of ['index.html','css','js','build.js'])fs.cpSync(path.join(root,f),path.join(tmp,f),{recursive:true});
 let bo='';try{bo=cp.execFileSync('node',['build.js'],{cwd:tmp}).toString()}catch(e){bo='HATA '+e.message}
 ok(/www\/ ready/.test(bo)&&fs.existsSync(path.join(tmp,'www','index.html'))&&fs.existsSync(path.join(tmp,'www','js','game.js')),'build.js assets/ klasoru OLMADAN da www/ uretiyor');
 const nWww=fs.readdirSync(path.join(tmp,'www','js'),{recursive:true}).filter(f=>f.endsWith('.js')).length;
 ok(nWww===18,'www/js icinde 18 JS dosyasi (17 modul + game.js): '+nWww);
 // workflow
 const wf=rd('.github/workflows/android-build.yml');
 const need=[['workflow_dispatch','elle tetikleme'],['actions/checkout@','checkout'],['java-version: \'17\'','JDK 17'],['actions/setup-node@','Node'],['node-version: \'18\'','Node 18'],['stat -c%s','APK boyut kontrolu'],['name: app-debug','artifact adi app-debug'],['npm install','npm bagimliliklari'],['npm run build','npm run build'],['cap add android','android uretimi'],['patch-android.js','yama'],['cap sync android','cap sync'],['gradlew assembleDebug','gradle assembleDebug'],['android/app/build/outputs/apk/debug/app-debug.apk','APK yolu'],['actions/upload-artifact@','artifact yukleme']];
 for(const [s,n] of need)ok(wf.includes(s),'workflow: '+n);
 let yamlOk='atlandi';try{cp.execFileSync('python3',['-c','import yaml,sys;yaml.safe_load(open(sys.argv[1]))',path.join(root,'.github/workflows/android-build.yml')]);yamlOk='ok'}catch(e){yamlOk='hata'}
 ok(yamlOk==='ok','workflow YAML sozdizimi gecerli');
 const order=['actions/checkout','setup-java','setup-node','npm install','npm run build','cap sync android','assembleDebug','upload-artifact'].map(s=>wf.indexOf(s));
 ok(order.every((v,i)=>v>=0&&(i===0||v>order[i-1])),'workflow adim sirasi istenen siraya uygun');
 // ===== STATIK: Android yamasi (Capacitor 6 sablonunu taklit eden iskelet uzerinde; GERCEK sablon degildir)
 const A=path.join(tmp,'android'),main=path.join(A,'app/src/main'),jd=path.join(main,'java/com/darkmystery/lostasylum');
 fs.mkdirSync(jd,{recursive:true});fs.mkdirSync(path.join(main,'res/values'),{recursive:true});
 fs.writeFileSync(path.join(main,'AndroidManifest.xml'),`<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application android:allowBackup="true" android:label="@string/app_name" android:theme="@style/AppTheme">
        <activity
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:name=".MainActivity"
            android:label="@string/title_activity_main"
            android:theme="@style/AppTheme.NoActionBarLaunch"
            android:launchMode="singleTask"
            android:exported="true">
            <intent-filter><action android:name="android.intent.action.MAIN" /><category android:name="android.intent.category.LAUNCHER" /></intent-filter>
        </activity>
        <provider android:name="androidx.core.content.FileProvider" android:authorities="\${applicationId}.fileprovider" android:exported="false" android:grantUriPermissions="true"></provider>
    </application>
    <uses-permission android:name="android.permission.INTERNET" />
</manifest>`);
 fs.writeFileSync(path.join(main,'res/values/strings.xml'),`<?xml version='1.0' encoding='utf-8'?>
<resources>
    <string name="app_name">Eski Ad</string>
    <string name="title_activity_main">Eski Ad</string>
    <string name="package_name">com.darkmystery.lostasylum</string>
    <string name="custom_url_scheme">com.darkmystery.lostasylum</string>
</resources>`);
 fs.writeFileSync(path.join(jd,'MainActivity.java'),'package com.darkmystery.lostasylum;\n\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {}\n');
 fs.mkdirSync(path.join(tmp,'scripts'));fs.copyFileSync(path.join(root,'scripts/patch-android.js'),path.join(tmp,'scripts/patch-android.js'));fs.copyFileSync(path.join(root,'capacitor.config.json'),path.join(tmp,'capacitor.config.json'));
 const patch=()=>cp.spawnSync('node',['scripts/patch-android.js','android'],{cwd:tmp,encoding:'utf8'});
 const r1=patch();const man=()=>fs.readFileSync(path.join(main,'AndroidManifest.xml'),'utf8');
 ok(r1.status===0,'patch-android.js hatasiz calisti');
 ok((man().match(/screenOrientation="sensorLandscape"/g)||[]).length===1&&/<activity[^>]*screenOrientation="sensorLandscape"[^>]*>/s.test(man()),'Manifest: ana activity sensorLandscape');
 ok(/configChanges="[^"]*orientation[^"]*screenSize/.test(man())&&/android:exported="true"/.test(man())&&/<provider/.test(man()),'Manifest: configChanges/exported/provider korundu');
 const sx=fs.readFileSync(path.join(main,'res/values/strings.xml'),'utf8');
 ok(/app_name">DARK MYSTERY</.test(sx)&&/title_activity_main">DARK MYSTERY</.test(sx)&&/package_name">com\.darkmystery\.lostasylum</.test(sx),'strings.xml: uygulama adi DARK MYSTERY, paket anahtarlari korundu');
 const ja=fs.readFileSync(path.join(jd,'MainActivity.java'),'utf8');
 ok(/^package com\.darkmystery\.lostasylum;/m.test(ja)&&/extends BridgeActivity/.test(ja)&&/FLAG_KEEP_SCREEN_ON/.test(ja)&&/systemBars\(\)/.test(ja)&&/CUTOUT_MODE_SHORT_EDGES/.test(ja),'MainActivity.java: paket dogru, immersive + ekran acik + notch');
 const before=man();const r2=patch();
 ok(r2.status===0&&man()===before,'Yama idempotent (2. calistirma manifesti degistirmedi)');
 const r3=cp.spawnSync('node',['scripts/patch-android.js','yok_klasor'],{cwd:tmp,encoding:'utf8'});
 ok(r3.status!==0,'android/ yoksa yama acik hatayla basarisiz oluyor');
 // ===== CHROMIUM: sahte Capacitor ile geri tusu + arka plan
 const srv=http.createServer((q,r)=>{let f=path.join(root,decodeURIComponent(q.url.split('?')[0]));if(f.endsWith(path.sep))f+='index.html';
  if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){r.statusCode=404;return r.end()}r.setHeader('Content-Type',M[path.extname(f)]||'text/plain');r.end(fs.readFileSync(f))});
 await new Promise(r=>srv.listen(0,r));const base='http://localhost:'+srv.address().port+'/';
 const br=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
 // Yatay, dokunmatik, telefon boyutu (Android CIHAZ DEGIL)
 const ctx=await br.newContext({viewport:{width:844,height:390},hasTouch:true,isMobile:true,deviceScaleFactor:2});
 await ctx.addInitScript(()=>{window.__cap={L:{},exited:0};window.Capacitor={isNativePlatform:()=>false,Plugins:{App:{addListener(n,f){window.__cap.L[n]=f;return Promise.resolve({remove(){}})},exitApp(){window.__cap.exited++}}}}});
 const pg=await ctx.newPage();const errs=[],ext=[];
 pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
 pg.on('request',q=>{if(!/^(http:\/\/localhost|data:|blob:)/.test(q.url()))ext.push(q.url())});
 const E=(f,a)=>pg.evaluate(f,a),vis=id=>E(id=>!document.getElementById(id).classList.contains('hid'),id);
 const back=async()=>{await E(()=>window.__cap.L.backButton());await sl(120)};
 await pg.goto(base+'?dmtest=1');await E(()=>localStorage.clear());await pg.reload();await sl(900);
 ok(await E(()=>innerWidth>innerHeight),'Ekran yatay (844x390)');
 ok(await E(()=>typeof window.__cap.L.backButton==='function'&&typeof window.__cap.L.appStateChange==='function'),'Capacitor App: backButton + appStateChange dinleyicileri kayitli');
 ok(await vis('menu'),'Menu gorunur');
 // dil: uc dil, anahtar adi geri dusmemeli
 const langs={};
 for(const l of ['tr','en','ru']){await pg.click('#bLang');await pg.click('#pbody button:text-is("'+({tr:'Türkçe',en:'English',ru:'Русский'}[l])+'")');await pg.click('#pBack');await sl(80);
  langs[l]=await E(()=>[...document.querySelectorAll('#menu button')].map(b=>b.textContent))}
 const keys=await E(()=>[...document.querySelectorAll('#menu button')].map(b=>b.dataset.i));
 ok(['tr','en','ru'].every(l=>langs[l].every((t,i)=>t&&t!==keys[i])),'Uc dil de menu etiketlerini yukluyor (anahtar adi geri dusmedi)');
 ok(new Set([langs.tr[0],langs.en[0],langs.ru[0]]).size===3,'Diller birbirinden farkli: '+[langs.tr[0],langs.en[0],langs.ru[0]].join(' | '));
 ok(await E(()=>document.documentElement.lang==='ru'),'html lang son secilen dile gore (ru)');
 await pg.click('#bLang');await pg.click('#pbody button:text-is("Türkçe")');await pg.click('#pBack');
 // menude Android Cikis dugmesi gorunuyor (Capacitor varken)
 ok(await E(()=>getComputedStyle(document.getElementById('bExit')).display!=='none'),'Capacitor varken menude CIKIS dugmesi gorunur');
 // ayarlar paneli + geri tusu
 await pg.click('#bSet');ok(await vis('panel'),'Ayarlar aciliyor');await back();ok(!(await vis('panel'))&&(await vis('menu')),'GERI: ayarlar kapandi, menuye donuldu, uygulama KAPANMADI');
 ok((await E(()=>__cap.exited))===0,'Ayarlardan geri uygulamadan cikmadi');
 // yeni oyun
 await pg.click('#bNew');await sl(1000);
 ok(await E(()=>__dmla.mode==='play')&&await vis('hud'),'NEW GAME: oyun basladi, HUD acik');
 ok(await E(()=>!!__dmla.ctx()&&__dmla.ctx().state==='running'),'Ses baglami calisiyor');
 // etkilesim dugmesi + esya
 await E(()=>__dmla.tp(-2.5,6));await E(()=>{__dmla.cam.yaw=0;__dmla.cam.pitch=0});await sl(400);
 ok(await vis('bInt'),'Esyanin yaninda ETKILESIM dugmesi gorunur');
 await pg.tap('#bInt');await sl(150);
 ok(await E(()=>__dmla.G.picked.bat===true),'ETKILESIM dugmesi (dokunma) esyayi aldi');
 // fener
 const f0=await E(()=>__dmla.flash);await pg.tap('#bFl');await sl(100);const f1=await E(()=>__dmla.flash);ok(f0!==f1,'FENER dugmesi (dokunma) durumu degistiriyor ('+f0+' -> '+f1+')');
 // envanter + geri
 await pg.tap('#bInv');await sl(100);ok(await vis('inv'),'ENVANTER aciliyor');
 await back();ok(!(await vis('inv'))&&await E(()=>__dmla.mode==='play'),'GERI: envanter kapandi, oyun surdu');
 // oyunda geri -> duraklat, tekrar geri -> devam
 await back();ok(await vis('pause')&&await E(()=>__dmla.mode==='ui'),'GERI (oyunda): duraklatma menusu');
 await pg.tap('#pSet');await sl(100);ok(await vis('panel')&&await vis('pause'),'Duraklatmadan Ayarlar acildi');
 await back();ok(!(await vis('panel'))&&await vis('pause'),'GERI: yalniz ayarlar kapandi, duraklatma duruyor');
 await back();ok(!(await vis('pause'))&&await E(()=>__dmla.mode==='play'),'GERI: oyun devam etti');
 // arka plana gecis
 const b0=await E(()=>__dmla.G.battery);await E(()=>__dmla.hide());await sl(200);
 ok(await vis('pause')&&await E(()=>__dmla.mode==='ui'),'ARKA PLAN: oyun otomatik duraklatildi');
 ok(await E(()=>JSON.parse(localStorage.getItem('dmla_save')).v===2),'ARKA PLAN: oyun kaydedildi (localStorage, v2)');
 ok(await E(()=>__dmla.ctx().state==='suspended'||__dmla.ctx().state==='closed'),'ARKA PLAN: ses askiya alindi ('+await E(()=>__dmla.ctx().state)+')');
 await E(()=>window.__cap.L.appStateChange({isActive:true}));await sl(250);
 ok(await E(()=>__dmla.ctx().state==='running'),'ON PLANA DONUS: ses devam etti');
 await pg.tap('#pRes');
 // ana menu + geri = cikis
 await pg.tap('#bPause');await pg.tap('#pMenu');await sl(300);ok(await vis('menu'),'Ana menuye donuldu');
 await back();ok((await E(()=>__cap.exited))===1,'GERI (ana menu): uygulamadan cikis (exitApp 1 kez)');
 // continue: kayit var
 ok(await E(()=>!document.getElementById('bCont').disabled),'CONTINUE etkin (kayit var)');
 await pg.click('#bCont');await sl(1000);
 ok(await E(()=>__dmla.mode==='play'&&__dmla.G.picked.bat===true),'CONTINUE: kayit yuklendi, alinan esya korunuyor');
 ok(ext.length===0,'Internet gerektirmiyor: yerel disi HICBIR istek yok'+(ext.length?' -> '+ext.slice(0,3):''));
 ok(errs.length===0,'JavaScript hatasi yok'+(errs.length?' -> '+errs.slice(0,3):''));
 // native: test kancasi kapali
 const c2=await br.newContext({viewport:{width:844,height:390},hasTouch:true});await c2.addInitScript(()=>{window.Capacitor={isNativePlatform:()=>true,Plugins:{}}});
 const p2=await c2.newPage();await p2.goto(base+'?dmtest=1');await sl(800);
 ok(await p2.evaluate(()=>typeof window.__dmla==='undefined'),'Native (Capacitor.isNativePlatform=true): test kancasi KAPALI; App eklentisi yokken de cokme yok');
 await br.close();srv.close();fs.rmSync(tmp,{recursive:true,force:true});
 console.log('\nNOT: Bu testler Chromium + sahte Capacitor ile yapildi. Gercek Android cihaz testi DEGILDIR.');
 console.log('\nSONUC: '+pass+' gecti, '+fail+' basarisiz');process.exit(fail?1:0)})();
