// A2 testi: mimari + 6 madde. Calistirma: PW_PATH=<playwright yolu> node tests/a2.test.js
const path=require('path'),fs=require('fs'),http=require('http');
const {chromium}=require(process.env.PW_PATH||'playwright');
const root=path.join(__dirname,'..'),M={'.html':'text/html','.js':'text/javascript','.css':'text/css'};
const missing=[];
const srv=http.createServer((q,r)=>{let f=path.join(root,decodeURIComponent(q.url.split('?')[0]));if(f.endsWith(path.sep))f+='index.html';
 if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){missing.push(q.url);r.statusCode=404;return r.end()}r.setHeader('Content-Type',M[path.extname(f)]||'text/plain');r.end(fs.readFileSync(f))});
let pass=0,fail=0;const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS  ':'FAIL  ')+n)};
const sl=ms=>new Promise(r=>setTimeout(r,ms));
const fx=n=>fs.readFileSync(path.join(__dirname,'fixtures',n),'utf8');
(async()=>{await new Promise(r=>srv.listen(0,r));const base='http://localhost:'+srv.address().port+'/';
 const br=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
 const ctx=await br.newContext({viewport:{width:800,height:360},hasTouch:true});const pg=await ctx.newPage();
 const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
 const E=(f,a)=>pg.evaluate(f,a),vis=id=>E(id=>!document.getElementById(id).classList.contains('hid'),id);
 const G=()=>E(()=>JSON.parse(JSON.stringify(__dmla.G))),P=()=>E(()=>[...__dmla.P]);
 const boot=async(u='?dmtest=1')=>{await pg.goto(base+u);await sl(900)};
 const cont=async()=>{await pg.click('#bCont');await sl(900)};
 const tp=async(x,z,yaw)=>{await E(a=>{__dmla.tp(a[0],a[1]);if(a[2]!==undefined){__dmla.cam.yaw=a[2];__dmla.cam.pitch=0}},[x,z,yaw]);await sl(150)};
 const hold=async(k,ms)=>{await pg.keyboard.down(k);await sl(ms);await pg.keyboard.up(k);await sl(60)};
 const act=async()=>{await E(()=>__dmla.interact());await sl(80)};
 const setSave=async o=>{await E(s=>localStorage.setItem('dmla_save',s),typeof o==='string'?o:JSON.stringify(o))};
 await pg.goto(base+'?dmtest=1');await E(()=>localStorage.clear());await boot();
 // ===== MIMARI
 const mods=await E(()=>['util','settings','save','audio','world','render','player','interact','input','ui'].every(m=>!!DM[m])&&Object.keys(DM.data).sort().join());
 ok(mods==='chapters,characters,docs,items,quests'||/chapters/.test(mods),'Tum moduller kayitli; veri dosyalari: '+mods.slice(0,60));
 ok(missing.length===0,'index.html\'in istedigi hicbir dosya 404 degil'+(missing.length?' -> '+missing:''));
 ok((await E(()=>document.querySelectorAll('script').length))===18,'18 klasik script (dis kaynak yok): '+(await E(()=>[...document.scripts].every(s=>!/^https?:/.test(s.getAttribute('src'))))));
 // veri degismezligi (build, esya gizlerken data'yi bozmamali)
 await pg.click('#bNew');await sl(900);
 const j0=await E(()=>JSON.stringify(DM.data.chapters[1]));await tp(-2.5,6,0);await act();
 ok((await G()).picked.bat&&(await E(()=>JSON.stringify(DM.data.chapters[1])))===j0,'Esya alinca harita VERISI bozulmuyor (veri/kod ayrimi saglam)');
 // ===== MADDE 2: checkpoint tutarliligi (konum + pil + envanter + bulmaca)
 const same=async()=>E(()=>{const g=__dmla.G,c=g.cp,P=__dmla.P;const eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  return eq(c.items,g.items)&&eq(c.doors,g.doors)&&eq(c.picked,g.picked)&&eq(c.solved,g.solved)&&Math.abs(c.battery-g.battery)<.5&&Math.abs(c.pos[0]-P[0])<1e-9&&Math.abs(c.pos[2]-P[2])<1e-9&&c.yaw===__dmla.cam.yaw});
 ok(await same(),'Esya alma ani: checkpoint = canli durum (esya, kapi, bulmaca, pil, konum, bakis)');
 await tp(4.5,13,0);await act();ok(await same(),'Anahtar sonrasi checkpoint tutarli');
 await tp(-.9,15,0);await act();await sl(200);ok(await same()&&(await G()).cp.doors.d_off,'Kapi acma sonrasi checkpoint tutarli');
 await tp(.45,19.4,0);await act();for(const k of ['4','1','7','2','OK'])await pg.click('#keys button:text-is("'+k+'")');await sl(150);
 ok(await same()&&(await G()).cp.solved.pad,'Bulmaca cozumu sonrasi checkpoint tutarli');
 const before=await G();await tp(0,2,1);await E(()=>{__dmla.G.battery=12;__dmla.G.items.length=0});
 await pg.click('#bPause');await pg.click('#pRst');await sl(900);const after=await G();
 ok(JSON.stringify(after.items)===JSON.stringify(before.cp.items)&&Math.abs(after.battery-before.cp.battery)<.6&&JSON.stringify(after.solved)===JSON.stringify(before.cp.solved)&&Math.abs((await P())[2]-before.cp.pos[2])<.01,'Restart: esya + pil + bulmaca + konum BIRLIKTE checkpoint degerlerine dondu');
 // kayit onarimi
 const A1=JSON.parse(fx('save_A1.json'));const clone=()=>JSON.parse(JSON.stringify(A1));
 const tryLoad=async o=>{await boot();await setSave(o);await boot();await cont();return G()};
 let o=clone();o.doors.d_pad=true;o.solved={};let g=await tryLoad(o);ok(g.solved.pad===true,'Onarim: sifreli kapi acik ama bulmaca isaretsiz -> bulmaca tamam sayildi');
 o=clone();o.doors.d_off=true;o.picked={};o.items=[];g=await tryLoad(o);ok(g.picked.key&&g.items.includes('key'),'Onarim: acik anahtarli kapi ama anahtar yok -> anahtar tamamlandi');
 o=clone();o.items=['bat','doc'];o.picked={};g=await tryLoad(o);ok(g.picked.bat&&g.picked.doc,'Onarim: envanterdeki esyalar "alindi" isaretlendi');
 o=clone();o.pos=[-3.9,1.6,4];g=await tryLoad(o);let p=await P();ok(Math.abs(p[0])<.01&&Math.abs(p[2]-1.5)<.01,'Onarim: duvarin icindeki konum -> baslangica alindi');
 o=clone();o.battery=250;g=await tryLoad(o);ok(g.battery>99&&g.battery<=100,'Onarim: pil 250 -> 100');
 o=clone();o.cp.doors.d_pad=true;o.cp.solved={};g=await tryLoad(o);ok(g.cp.solved.pad===true,'Onarim checkpoint icin de gecerli');
 // ===== MADDE 1: pil sifirken checkpoint / continue
 await boot();await E(()=>localStorage.clear());await boot();await pg.click('#bNew');await sl(900);
 await E(()=>{__dmla.G.cp.battery=0;__dmla.G.battery=70;window.__frames=[];const d=DM.render.draw;DM.render.draw=fr=>{window.__frames.push([fr.fl,__dmla.G?__dmla.G.battery:-1]);return d(fr)}});
 await pg.click('#bPause');await pg.click('#pRst');
 await pg.waitForFunction(()=>__dmla.mode==='play',null,{timeout:4000});   // geri yukleme tamamlandi
 const fl=[];for(let i=0;i<30;i++){fl.push(await E(()=>__dmla.flash));await sl(40)}
 ok(await E(()=>{const f=DM.save.flashAfterRestore;return f({battery:0})===false&&f({battery:.01})===true&&f({battery:100})===true}),'KURAL (DM.save.flashAfterRestore): pil 0 -> kapali, pil>0 -> acik');
 ok(await E(()=>JSON.stringify(__dmla.G.cp)!==undefined&&__dmla.flash===false),'Geri yukleme sonrasi fener durumu pil 0 ile uyumlu (kapali)');
 const fr=await E(()=>window.__frames.filter(f=>f[1]===0));
 ok(fr.length>10&&fr.every(f=>f[0]===0),'Pil=0 geri yukleme: '+fr.length+' cizim karesinin HICBIRINDE fener isigi yok (tek karelik parlama dahil)');
 ok(fl.every(x=>x===false),'Pil=0 checkpoint geri yuklenince fener ASLA acilmiyor (geri yukleme anindan itibaren 30 ornek, titreme yok)');
 ok((await E(()=>document.getElementById('msg').textContent)).includes('Pil bitti')&&(await G()).battery===0,'Kullaniciya "Pil bitti" bildirildi, pil 0');
 await pg.click('#bFl');await sl(100);ok((await E(()=>__dmla.flash))===false,'Pil 0 iken fener dugmesi acamiyor');
 await E(()=>{__dmla.G.cp.battery=50});await pg.click('#bPause');await pg.click('#pRst');await sl(900);ok((await E(()=>__dmla.flash))===true,'Pil>0 checkpoint: fener acik dogar');
 o=clone();o.battery=0;g=await tryLoad(o);ok((await E(()=>__dmla.flash))===false,'CONTINUE ile pil=0 kayit: fener kapali basliyor');
 // ===== MADDE 5: geriye donuk uyumluluk
 for(const [name,file] of [['ORIJINAL surum (cp=dizi, surumsuz)','save_original.json'],['A1 surumu (cp=nesne, surumsuz)','save_A1.json']]){
  await boot();await E(([s,t])=>{localStorage.clear();localStorage.setItem('dmla_save',s);localStorage.setItem('dmla_set',t)},[fx(file),fx(file+'.set')]);await boot();
  const en=!(await E(()=>document.getElementById('bCont').disabled));await cont();g=await G();p=await P();
  ok(en&&(await E(()=>__dmla.mode))==='play'&&g.items.join()==='bat,key'&&g.doors.d_off&&g.picked.bat&&g.picked.key&&g.battery>90&&g.battery<100,name+': CONTINUE ilerlemeyi aynen yukledi');
  ok((await E(()=>__dmla.S.lang))==='en'&&(await E(()=>__dmla.S.vol))===.4,name+': ayarlar korundu (dil=en, ses=.4)');
  await tp(-.9,15,0);await hold('d',1500);ok((await P())[0]<-2,name+': acik kapi calisiyor');
  await E(()=>{__dmla.G.items.length=0});await pg.click('#bPause');await pg.click('#pRst');await sl(900);
  ok((await G()).items.join()==='bat,key'&&g.cp&&(await E(()=>JSON.parse(localStorage.dmla_save).v))===2,name+': Restart calisti, kayit v2 semasina yukseltildi');}
 await boot();await setSave({...clone(),v:99});await boot();
 ok((await E(()=>document.getElementById('bCont').disabled))&&(await E(()=>localStorage.dmla_save_bad))!==null&&errs.length===0,'Gelecek surum (v99) kaydi: reddedildi, YEDEKLENDI, coktu yok');
 // ===== MADDE 3: mentese mimarisi
 await boot();await E(()=>localStorage.clear());await boot();await pg.click('#bNew');await sl(900);
 await E(()=>{const b={p:[0,1.3,5],s:[1.2,2.6,.15],c:[.5,.3,.2],solid:true,em:0,lift:0,off:[0,0],rot:0,piv:[0,0,0]};
  __dmla.boxesArr().push(b);__dmla.objs().push({id:'t_h',t:'door',b,lock:null,pos:[0,5],r:2.2,kind:'hinge',def:{hinge:{pivot:[-.6,5],angle:-Math.PI/2}},anim:0});window.__hb=b});
 await tp(0,3,0);await hold('w',1500);ok((await P())[2]<4.7,'Menteseli kapi (kapali) yolu kapatiyor (z='+(await P())[2].toFixed(2)+')');
 const hs=async a=>E(a=>{const o=__dmla.objs().find(o=>o.id==='t_h');o.anim=a;__dmla.DM.world.applyDoor(o);return[__hb.rot,__hb.piv[0],__hb.piv[2]]},a);
 let r=await hs(0);ok(!(await E(()=>__dmla.DM.world.collides(__dmla.boxesArr(),-.6,5.6,.3))),'Kapaliyken mentese tarafindaki bos nokta serbest');
 r=await hs(1);ok(Math.abs(r[0]+Math.PI/2)<1e-9&&r[1]===-.6&&r[2]===5,'Acik: dondurme -90 derece, pivot = mentese noktasi');
 ok(await E(()=>__dmla.DM.world.collides(__dmla.boxesArr(),-.6,5.6,.3)),'Donmus kapi carpismasi: kapi kanadinin yeni yerinde ENGEL var');
 ok(!(await E(()=>__dmla.DM.world.collides(__dmla.boxesArr(),0,5,.3))),'Donmus kapi carpismasi: kapinin eski yeri artik serbest');
 await tp(0,3,0);await hold('w',1500);ok((await P())[2]>6,'Menteseli kapi acikken gecilebiliyor (z='+(await P())[2].toFixed(2)+')');
 await hs(.5);await tp(.3,1.9,0);await E(()=>{__dmla.cam.pitch=.1});await sl(300);await pg.screenshot({path:'/tmp/hinge_half.png'});
 // ===== MADDE 4: test kancasi yalniz test ortaminda
 const p2=await ctx.newPage();await p2.goto(base);await sl(700);
 ok(await p2.evaluate(()=>typeof window.__dmla==='undefined'&&DM.testMode===false),'Normal acilis (?dmtest yok): window.__dmla TANIMSIZ');
 await p2.click('#bNew');await sl(150);if(await p2.evaluate(()=>!document.getElementById('conf').classList.contains('hid')))await p2.click('#cYes');await sl(900);ok(await p2.evaluate(()=>!document.getElementById('hud').classList.contains('hid')),'__dmla olmadan da oyun tam calisiyor (HUD acik)');
 const p3=await ctx.newPage();await p3.addInitScript(()=>{window.Capacitor={isNativePlatform:()=>true,Plugins:{}}});await p3.goto(base+'?dmtest=1');await sl(700);
 ok(await p3.evaluate(()=>typeof window.__dmla==='undefined'&&DM.testMode===false),'Android/native ortamda ?dmtest=1 bile KANCAYI ACMIYOR');
 ok(await pg.evaluate(()=>typeof window.__dmla==='object'),'?dmtest=1 ile yerel tarayicida kanca aciliyor (testler icin)');
 ok(errs.length===0,'JavaScript hatasi yok'+(errs.length?' -> '+errs.slice(0,3).join(' | '):''));
 console.log('\nSONUC: '+pass+' gecti, '+fail+' basarisiz');await br.close();srv.close();process.exit(fail?1:0)})().catch(e=>{console.error('TEST CRASH',e);process.exit(2)});
