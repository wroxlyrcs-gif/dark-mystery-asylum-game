// A1 testi: Playwright + Chromium (yazilim WebGL). Calistirma: PW_PATH=<playwright yolu> node tests/a1.test.js
const path=require('path'),fs=require('fs'),http=require('http');
const {chromium}=require(process.env.PW_PATH||'playwright');
const root=path.join(__dirname,'..'),M={'.html':'text/html','.js':'text/javascript','.css':'text/css'};
const srv=http.createServer((q,r)=>{let f=path.join(root,decodeURIComponent(q.url.split('?')[0]));if(f.endsWith(path.sep))f+='index.html';
 if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){r.statusCode=404;return r.end()}r.setHeader('Content-Type',M[path.extname(f)]||'text/plain');r.end(fs.readFileSync(f))});
let pass=0,fail=0;const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS  ':'FAIL  ')+n)};
const sl=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{await new Promise(r=>srv.listen(0,r));const url='http://localhost:'+srv.address().port+'/?dmtest=1';
 const br=await chromium.launch({args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required']});
 const ctx=await br.newContext({viewport:{width:800,height:360},hasTouch:true});const pg=await ctx.newPage();
 const errs=[];pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
 const E=(f,a)=>pg.evaluate(f,a),vis=id=>E(id=>!document.getElementById(id).classList.contains('hid'),id);
 const P=()=>E(()=>[...__dmla.P]),G=()=>E(()=>JSON.parse(JSON.stringify(__dmla.G)));
 const boot=async()=>{await pg.reload();await sl(900)};
 const newGame=async()=>{await pg.click('#bNew');await sl(900)};
 const tp=async(x,z,yaw)=>{await E(a=>{__dmla.tp(a[0],a[1]);if(a[2]!==undefined){__dmla.cam.yaw=a[2];__dmla.cam.pitch=0}},[x,z,yaw]);await sl(150)};
 const hold=async(k,ms)=>{await pg.keyboard.down(k);await sl(ms);await pg.keyboard.up(k);await sl(60)};
 const act=async()=>{await E(()=>__dmla.interact());await sl(80)};
 await pg.goto(url);await E(()=>localStorage.clear());await boot();
 ok(errs.length===0&&await vis('menu'),'Acilis: menu gorunur, hata yok');
 // ---- A1.2 bozuk veri
 await E(()=>localStorage.setItem('dmla_set','{bozuk'));await boot();
 ok(errs.length===0&&await vis('menu')&&(await E(()=>__dmla.S.lang))==='tr','Bozuk ayar kaydi: coktu yok, varsayilanlar yuklendi');
 await E(()=>localStorage.setItem('dmla_set','{"lang":"xx","vol":99,"sens":"a","q":7,"bri":-5}'));await boot();
 const s=await E(()=>__dmla.S);ok(s.lang==='tr'&&s.vol===1&&s.sens===1&&s.q===2&&s.bri===.6,'Gecersiz ayar degerleri temizlendi/sinirlandi');
 const bads=['{bozuk','null','[]','{"x":1}','{"items":"abc","doors":{},"picked":{},"solved":{},"pos":[0,1,1],"battery":50}','{"items":[],"doors":{},"picked":{},"solved":{},"pos":[0,1],"battery":50}','{"items":[],"doors":{},"picked":{},"solved":{},"pos":[0,1,1],"battery":"x"}','{"items":[1],"doors":{},"picked":{},"solved":{},"pos":[0,1,1],"battery":5}'];
 let allBad=true;for(const b of bads){await E(b=>{localStorage.clear();localStorage.setItem('dmla_save',b)},b);await boot();
  const d=await E(()=>document.getElementById('bCont').disabled);if(!d||errs.length)allBad=false}
 ok(allBad,'8 farkli bozuk/gecersiz kayit: Continue kapali, JS hatasi yok');
 ok(await E(()=>localStorage.getItem('dmla_save_bad')!==null),'Bozuk kayit silinmedi, dmla_save_bad olarak yedeklendi');
 await E(()=>localStorage.clear());await boot();
 // ---- A1.5 kayit yokken onay yok + ilk kayit
 await pg.click('#bNew');await sl(150);ok(!(await vis('conf')),'Kayit yokken yeni oyun onay sormadan basliyor');await sl(800);
 ok((await E(()=>__dmla.mode))==='play','Yeni oyun basladi (mode=play)');
 ok(await E(()=>{const s=JSON.parse(localStorage.dmla_save);return s.cp&&!Array.isArray(s.cp)&&s.cp.items.length===0}),'Yeni oyunda ilk checkpoint kaydi olustu');
 // ---- A1.1 pause -> ayarlar z-order
 await pg.click('#bPause');await pg.click('#pSet');await sl(100);
 ok(await E(()=>{const r=document.querySelector('#pbody label').getBoundingClientRect();return document.elementFromPoint(r.x+r.width/2,r.y+r.height/2).closest('#panel')!==null}),'Pause icinden acilan Ayarlar paneli ustte (tiklanabilir)');
 await pg.click('#pBack');ok(await vis('pause')&&!(await vis('panel')),'Ayarlar kapaninca Pause menusu geri geldi');
 await pg.click('#pRes');await sl(100);
 // ---- A1.4 kapilar
 await tp(4.5,13,0);await act();ok((await G()).items.includes('key'),'Anahtar alindi');
 ok(await E(()=>__dmla.G.cp.items.includes('key')&&JSON.parse(localStorage.dmla_save).cp.items.includes('key')),'Anahtar sonrasi checkpoint (bellek + localStorage)');
 await tp(-.4,15,-Math.PI/2);await pg.screenshot({path:'/tmp/door_closed.png'});
 await tp(-.9,15,0);await hold('d',1500);let p=await P();ok(p[0]>-1.25,'Kapali kapi oyuncuyu durduruyor (x='+p[0].toFixed(2)+')');
 await tp(-.9,15,0);await act();ok(await E(()=>__dmla.G.doors.d_off===true&&__dmla.G.cp.doors.d_off===true),'Anahtarla kapi acildi + checkpoint');
 await hold('d',300);p=await P();ok(p[0]>-1.25,'Animasyon sirasinda (0.3 sn) kapi hala yolu kapatiyor (x='+p[0].toFixed(2)+')');
 await sl(300);const mid=await E(()=>{const o=__dmla.objs().find(o=>o.id==='d_off');return o.b.off[1]});
 await tp(-.4,15,-Math.PI/2);await pg.screenshot({path:'/tmp/door_mid.png'});
 await sl(1000);const fin=await E(()=>{const o=__dmla.objs().find(o=>o.id==='d_off');return o.b.off[1]});
 ok(fin>=1.19&&fin<=1.21,'Animasyon tamamlandi: kapi duvara '+fin.toFixed(2)+' m kaydi');
 await tp(-.4,15,-Math.PI/2);await pg.screenshot({path:'/tmp/door_open.png'});
 await tp(-.9,15,0);await hold('d',1500);p=await P();ok(p[0]<-2,'Acik kapidan gecilebiliyor (x='+p[0].toFixed(2)+')');
 // ---- A1.3 ses
 const c1=await E(()=>{window.__c=__dmla.ctx();return window.__c?window.__c.state:'yok'});ok(c1!=='yok'&&c1!=='closed','Oyunda ses baglami acik ('+c1+')');
 await pg.click('#bPause');await pg.click('#pMenu');await sl(300);
 ok(await E(()=>__dmla.ctx()===null&&window.__c.state==='closed'),'Ana menuye donunce ses baglami KAPATILDI (yagmur/ruzgar tamamen durdu)');
 ok(await vis('menu')&&!(await E(()=>document.getElementById('bCont').disabled)),'Menu acik, Continue etkin');
 // ---- A1.5 onay penceresi
 const raw0=await E(()=>localStorage.dmla_save);
 await pg.click('#bNew');await sl(100);ok(await vis('conf'),'Kayit varken YENI OYUN onay penceresi aciyor');
 ok((await E(()=>localStorage.dmla_save))===raw0,'Onay beklerken kayit degismedi');
 await pg.click('#cNo');await sl(100);ok(!(await vis('conf'))&&await vis('menu')&&(await E(()=>localStorage.dmla_save))===raw0,'HAYIR: menuye donuldu, kayit ayni');
 await pg.click('#bChap');await pg.click('#panel button:first-child');await sl(100);ok(await vis('conf'),'Bolum Sec > Bolum 1 de ayni onayi istiyor');
 await pg.click('#cNo');await pg.click('#pBack');await sl(100);
 // ---- continue butunlugu + A1.6 restart
 await pg.click('#bCont');await sl(900);
 ok(await E(()=>__dmla.mode==='play'&&__dmla.G.items.includes('key')&&__dmla.G.doors.d_off&&__dmla.ctx()!==null),'CONTINUE: durum + acik kapi + yeni ses baglami geri geldi');
 await tp(-.9,15,0);await hold('d',1200);p=await P();ok(p[0]<-2,'Kayittan yuklenen acik kapi (animasyonsuz) gecilebilir');
 await tp(-2.5,6,0);await act();ok((await G()).items.includes('bat'),'Pil alindi (checkpoint olustu)');
 const bat0=await E(()=>__dmla.G.battery);
 await pg.click('#bInv');for(const b of await pg.$$('#ilist button')){if((await b.textContent()).startsWith('Pil')){await b.click();break}}
 await pg.click('#iClose');await sl(100);
 ok(await E(b=>!__dmla.G.items.includes('bat')&&__dmla.G.battery>99.5&&b<99.9,bat0),'Pil gercekten kullanildi: envanterden dustu, seviye ~100 (onceki '+bat0.toFixed(1)+') (checkpoint disi degisiklik)');
 await tp(0,2,1);await pg.click('#bPause');await pg.click('#pRst');await sl(900);
 const r=await G();p=await P();
 ok(r.items.includes('bat')&&r.items.includes('key')&&r.battery<99.9&&Math.abs(p[0]+2.5)<.2&&Math.abs(p[2]-6)<.2,'RESTART: esyalar, pil seviyesi ve konum SON CHECKPOINTE donduruldu (konum '+p[0].toFixed(1)+','+p[2].toFixed(1)+')');
 ok((await E(()=>__dmla.mode))==='play'&&await vis('hud')&&!(await vis('load')),'Restart sonrasi oyun devam ediyor');
 ok(await E(()=>JSON.parse(localStorage.dmla_save).items.includes('bat')),'Restart sonrasi kayit da checkpoint durumunda');
 // ---- eski format kayit goçu (cp dizi idi)
 await pg.click('#bPause');await pg.click('#pMenu');await sl(300);
 await E(()=>{const s=JSON.parse(localStorage.dmla_save);s.cp=[0,1.6,1.5];localStorage.dmla_save=JSON.stringify(s)});await boot();
 ok(!(await E(()=>document.getElementById('bCont').disabled)),'Eski formatli kayit (cp=dizi) gecerli kabul edildi');
 await pg.click('#bCont');await sl(900);await pg.click('#bPause');await pg.click('#pRst');await sl(900);
 ok((await E(()=>__dmla.mode))==='play'&&(await G()).items.includes('key'),'Eski kayitla Restart cokmedi, ilerleme korundu');
 // ---- regresyon: sifre paneli, son kapi, bolum sonu
 await pg.click('#bPause');await pg.click('#pRes');await sl(100);
 await tp(.45,19.4,0);await act();ok(await vis('pad'),'Sifre paneli aciliyor');
 for(const k of ['4','1','7','2','OK'])await pg.click('#keys button:text-is("'+k+'")');await sl(100);
 ok(await E(()=>__dmla.G.solved.pad===true&&__dmla.G.cp.solved.pad===true),'4172 dogru + checkpoint');
 await tp(0,19.5,0);await act();await sl(1200);await tp(0,19.5,0);await hold('w',1500);p=await P();ok(p[2]>21,'Sifreli kapi (yatay kayan) acildi ve gecildi (z='+p[2].toFixed(2)+')');
 await tp(0,22.5,0);await act();ok(await vis('doc'),'Bolum sonu belgesi gosterildi');
 await pg.click('#dClose');await sl(300);ok(await vis('menu')&&(await E(()=>__dmla.ctx()===null)),'Bolum sonu: menuye donuldu, ses durdu');
 // ---- dokunmatik regresyon
 await E(()=>localStorage.clear());await boot();await newGame();
 const cdp=await ctx.newCDPSession(pg),T=(t,pts)=>cdp.send('Input.dispatchTouchEvent',{type:t,touchPoints:pts});
 const jr=await E(()=>{const r=document.getElementById('joy').getBoundingClientRect();return[r.x+r.width/2,r.y+r.height/2]});
 const z0=(await P())[2],y0=await E(()=>__dmla.cam.yaw);
 await T('touchStart',[{x:jr[0],y:jr[1],id:1}]);await T('touchMove',[{x:jr[0],y:jr[1]-30,id:1}]);
 await T('touchStart',[{x:jr[0],y:jr[1]-30,id:1},{x:600,y:150,id:2}]);await T('touchMove',[{x:jr[0],y:jr[1]-30,id:1},{x:680,y:150,id:2}]);await sl(700);
 ok((await P())[2]>z0+.8&&(await E(()=>__dmla.cam.yaw))<y0-.2,'Dokunmatik: joystick ileri + es zamanli kamera surukleme calisiyor');
 await T('touchEnd',[]);
 ok(errs.length===0,'Butun test boyunca JavaScript hatasi yok'+(errs.length?' -> '+errs.slice(0,3).join(' | '):''));
 console.log('\nSONUC: '+pass+' gecti, '+fail+' basarisiz');await br.close();srv.close();process.exit(fail?1:0)})().catch(e=>{console.error('TEST CRASH',e);process.exit(2)});
