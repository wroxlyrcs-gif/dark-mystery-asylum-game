// Copies the web game into www/ for Capacitor. No external dependencies, no CDN.
// B: eksik klasor (ornegin Git'in izlemedigi bos assets/) artik build'i cokertmez.
const fs=require('fs'),path=require('path');
fs.rmSync('www',{recursive:true,force:true});fs.mkdirSync('www',{recursive:true});
for(const f of ['index.html','css','js','assets']){
 if(!fs.existsSync(f)){if(f==='assets')console.log('assets/ yok, atlandi');else throw new Error('Gerekli kaynak yok: '+f);continue}
 fs.cpSync(f,path.join('www',f),{recursive:true})}
console.log('www/ ready');
