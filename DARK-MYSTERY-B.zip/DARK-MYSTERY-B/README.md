# DARK MYSTERY: THE LOST ASYLUM — Phase 1 (+ B: Android altyapısı)

> B aşaması: bkz. `SETUP-B.md`, `CHANGES-B.md`, `TEST-REPORT-B.md`, `MISSING-FEATURES-B.md`. APK henüz ÜRETİLMEDİ (bkz. rapor).


## Durum (dürüst özet)
**Faz 1: yalnızca Bölüm 1 oynanabilir.** Bölüm 2–5, 3 son, gizemli varlık ve çoğu bulmaca HENÜZ YAPILMADI.
APK **oluşturulmadı** (üretim ortamında ağ erişimi ve Android SDK yok).

### Çalışan ve test edilenler
- Özel WebGL 3D motoru (Three.js/CDN yok; sıfır dış bağımlılık), fener konisi, karanlık, sis, titreyen ışık, prosedürel doku
- Ana menü (animasyonlu 3D koridor), Yeni Oyun, Devam (kayıt varsa aktif), Bölüm Seç (2–5 kilitli), Ayarlar, Dil (TR/EN/RU), Emeği Geçenler
- Ayarlar kalıcı: ses, hassasiyet, parlaklık, grafik kalitesi (çözünürlük ölçeği)
- Dokunmatik: sol sanal joystick, sağ kamera sürükleme (aynı anda), INTERACT/KOŞ/FENER/ENVANTER, duraklatma menüsü
- Bölüm 1: giriş holü, koridor, resepsiyon, ofis, final odası; pil, anahtar, belge, kilitli kapı, 4 haneli şifre paneli (4172), bölüm sonu
- Envanter (pil kullanma, belge okuma), pil sistemi, otomatik kayıt/yükleme, WebAudio ile sentezlenmiş yağmur/rüzgâr/adım/kapı sesleri
- Rastgele korku olayları (ışık titremesi, uzak ses, kapı çarpması)
- Headless Chromium testi: menü, oyun başlatma, pil/anahtar/belge alma, kilitli kapı, konsol hatası yok

### Yapılmadı
Bölüm 2–5, 15 bulmacanın çoğu (şu an ~3), gizemli varlık, üç son, ayak sesi/gölge olayları, merdiven, eğilme, dolap, vibrasyon/FOV/kamera ters ayarları, ses dosyaları (şimdilik sentez), doku sıkıştırma, Android projesi (`android/` üretilmedi), APK, gerçek cihaz testi.

## Çalıştırma (PC)
`index.html` dosyasını Chrome ile açın (WASD + sürükle, E etkileşim, F fener).

## APK üretme (kendi bilgisayarınızda: Node 18+, Android Studio/SDK, JDK 17)
```
npm install
npx cap add android      # android-manifest-notes.xml'e göre sensorLandscape ayarlayın
npm run apk              # çıktı: android/app/build/outputs/apk/debug/
```

## Mimari (A2)
Klasik `<script>` + tek global `DM` (ES module yok → `index.html` dogrudan Chrome'da da, Capacitor'da da calisir; derleme adimi/kutuphane yok).
Script sirasi `index.html`'dedir; `DM.need(...)` eksik modulu acik hatayla bildirir.

| Katman | Dosya | Gorev |
|---|---|---|
| cekirdek | core/dm.js, util.js | isim alani, test modu bayragi, saklama/dogrulama yardimcilari |
| ayar/dil | core/settings.js, data/i18n.js | Language Manager, ayarlar |
| kayit | core/save.js | Save Manager: sema v2, eski kayit goci, tutarlilik onarimi, checkpoint |
| dunya | core/world.js | veriden dunya, **kapi turleri kayit defteri**, carpisma |
| render | render/renderer.js | WebGL; kutu basina `rot`/`piv` (menteșe) destegi |
| oyuncu | core/player.js, input.js, interact.js | hareket+kamera, dokunmatik/klavye, etkilesim aramasi |
| arayuz/ses | core/ui.js, audio.js | UI Manager, Audio Manager |
| orkestra | game.js | durum makinesi, baslat/yukle/restart, dongu, dugme baglantilari |
| veri | data/chapter1.js, items.js, docs.js, characters.js, quests.js | harita, esya, belge, karakter kimligi, gorev semasi |

**Yeni kapi turu eklemek:** `world.js > doorKinds` icine `{apply(o,e){...}}` ekleyin (e: 0..1 yumusatilmis ilerleme), haritada kapiya `kind:'ad'` yazin.
**Menteseli kapi** hazirdir: `{kind:'hinge', hinge:{pivot:[x,z], angle:-1.57}}`. Bolum 1 haritasi kullanmaz.
**Test kancasi:** `window.__dmla` yalnizca `?dmtest=1` ile ve Android-disi calisirken vardir. Testler: `npm test` (Playwright gerekir: `PW_PATH` veya `npm i -D playwright`).
**Kayit:** `dmla_save` (v2). Eski kayitlar (orijinal ve A1) otomatik uyarlanir; gecersiz/gelecek surum kaydi silinmez, `dmla_save_bad`'e yedeklenir.
