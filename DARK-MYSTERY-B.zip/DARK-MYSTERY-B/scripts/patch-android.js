#!/usr/bin/env node
/* B asamasi: `npx cap add android` ile uretilen RESMI Capacitor 6 sablonunu bu oyun icin ayarlar.
   Idempotenttir (tekrar calistirmak zararsizdir). Dis bagimlilik yok.
   Yaptiklari:
     1) AndroidManifest: ana activity -> android:screenOrientation="sensorLandscape"
     2) strings.xml: uygulama adi -> capacitor.config.json appName
     3) MainActivity.java: tam ekran (immersive), ekran acik kalsin, kesik (notch) alanina cizim
   Kullanim: node scripts/patch-android.js [androidKlasoru=android] */
const fs=require('fs'),path=require('path');
const root=path.resolve(process.argv[2]||'android');
const cfg=JSON.parse(fs.readFileSync(path.join(__dirname,'..','capacitor.config.json'),'utf8'));
const fail=m=>{console.error('PATCH HATASI: '+m);process.exit(1)};
const rd=f=>fs.readFileSync(f,'utf8'),wr=(f,t)=>fs.writeFileSync(f,t);
if(!fs.existsSync(root))fail('android klasoru yok: '+root+' (once: npx cap add android)');
const main=path.join(root,'app','src','main');

// 1) Manifest
const mf=path.join(main,'AndroidManifest.xml');if(!fs.existsSync(mf))fail('AndroidManifest.xml yok');
let m=rd(mf);
m=m.replace(/<activity\b([^>]*?)(\/?)>/,(all,attrs,self)=>{
 attrs=attrs.replace(/\s+android:screenOrientation="[^"]*"/g,'').replace(/\s+$/,'');
 return '<activity'+attrs+'\n            android:screenOrientation="sensorLandscape"'+self+'>'});
wr(mf,m);
if(!/android:screenOrientation="sensorLandscape"/.test(rd(mf)))fail('manifest yamasi uygulanamadi (<activity> bulunamadi?)');
if(!/android:configChanges="[^"]*orientation[^"]*screenSize/.test(rd(mf)))console.warn('UYARI: activity configChanges orientation|screenSize icermiyor; donmede aktivite yeniden baslayabilir.');

// 2) Uygulama adi
const sf=path.join(main,'res','values','strings.xml');
if(fs.existsSync(sf)){let s=rd(sf);const esc=cfg.appName.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/'/g,"\\'");
 for(const k of ['app_name','title_activity_main'])s=s.replace(new RegExp('(<string name="'+k+'">)[^<]*(</string>)'),'$1'+esc+'$2');wr(sf,s)}
else console.warn('UYARI: strings.xml bulunamadi, uygulama adi degistirilmedi');

// 3) MainActivity.java (paket adi mevcut dosyadan okunur)
const jroot=path.join(main,'java');let ma=null;
(function walk(d){if(!fs.existsSync(d))return;for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(e.name==='MainActivity.java')ma=p}})(jroot);
if(!ma)fail('MainActivity.java bulunamadi');
const pkg=(rd(ma).match(/^\s*package\s+([\w.]+)\s*;/m)||[])[1]||cfg.appId;
if(pkg!==cfg.appId)console.warn('UYARI: MainActivity paketi ('+pkg+') appId ('+cfg.appId+') ile ayni degil');
wr(ma,`package ${pkg};

import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

/* DARK MYSTERY: tam ekran (immersive), ekran acik kalir, kesik alana cizim. (scripts/patch-android.js tarafindan uretilir) */
public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
      WindowManager.LayoutParams lp = getWindow().getAttributes();
      lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
      getWindow().setAttributes(lp);
    }
    enterImmersive();
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) enterImmersive();
  }

  private void enterImmersive() {
    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
    c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    c.hide(WindowInsetsCompat.Type.systemBars());
  }
}
`);
console.log('Android yamasi tamam: sensorLandscape + immersive + '+cfg.appName);
